#Christian Diaz-Caez
#WinPython2.7
#Script 1

import mysql.connector
import numpy as np
from beautifultable import BeautifulTable
from numpy import *
import math
import os, sys
sys.setrecursionlimit(10000)

cnx = mysql.connector.connect(host='localhost',
                             user='root',
                             password='',
                             database='humanterrain')
try:
    cursor = cnx.cursor()
    cursor.execute("SELECT * FROM `realdata`")
    DB_table = np.array(cursor.fetchall())

finally:
    cnx.close()
alert = "DataBase is empty"
if len(DB_table) == 0:
    alert_value = True
    #alert is bolean, just to alert other scritps that are calling this one. if alert_value = 1 abort and alert
else:
    alert_value = False
    #############################

    No_data = DB_table[:,0]    #id number (primary key from DB)   1st coulumn
    temp_ht = np.delete(DB_table, np.s_[len(DB_table[0])-1], axis=1)
    result = np.delete(temp_ht, np.s_[0], axis=1)
    binary_class = DB_table[:,(len(DB_table[0])-1)]    #last column

    No_data = np.transpose(No_data)
    Human_Terrain_temp = np.transpose(result)
    binary_class = np.transpose(binary_class)


    # Declare Human Terrain variables as lists
    def str_to_num(array):

            for q, p in enumerate(array):
                if p == '0':
                    array[q] = 0

            for q, p in enumerate(array):
                if  p == '1':
                    array[q] = 1
            for q, p in enumerate(array):
                if p == 'nan' or p == 'NAN' or p == 'NaN':
                    array[q] = float('nan')
                    #print "hola"
            return

    Human_Terrain = []
    for _ in Human_Terrain_temp:
        a = []
        for d in _:
            a.append(float(d))
        Human_Terrain.append(a)


    print "Number of Samples: ", len(Human_Terrain[0])
    print " "

    # Assign threat class for each outcomes
    table_samples = BeautifulTable()
    sample_class = []  # blank array where we will to assign a threat class value to each HT outcome.
    index_T_class = []
    index_NT_class = []

    #cadena = "Enumerated HT data samples".capitalize()
    #print " "
    #print cadena.center(76, "=")
    #print " "

    Data_no = []
    u = 1
    while u <= len(Human_Terrain[0]):  #TODO IMPROVEMENT #data no using the HT variable 0 as a reference
        Data_no.append(u)
        u += 1
    _cols = [Data_no]
    for _ht in Human_Terrain:
        _col = []
        for _ in _ht:
            _col.append(_)
        _cols.append(_col)

    for i in range(len(binary_class)):
        if binary_class[i] == "1":
            sample_class.append(1)
            index_T_class.append(i)
        else:
            sample_class.append(0)
            index_NT_class.append(i)

    #print "index_T_class", len(index_T_class)
    #print "index_NT_class", len(index_NT_class)

    _cols.append(sample_class)

    _cols_transpose = [[r[col] for r in _cols] for col in range(len(_cols[0]))]


    table_samples.append_row(["No.", "HT 0", "HT 1", "HT 2", "HT 3", "HT 4", "HT 5", "HT 6", "HT 7", "HT 8", "HT9", "HT 10", "HT 11", "HT 12", "HT 13", "HT 14", "HT 15", "HT 16", "Class"])

    #table_samples.append_row(["No.", "HT variable 0", "HT variable 1", "HT variable 2", "HT variable 3", "HT variable 4", "HT variable 5", "HT variable 6", "Class"])
    #print table_samples


    # find lower value X1
    def lower_HT(Human_Terrain):
        count = 0
        for _ in Human_Terrain:
            if isnan(_) == True:
                count += 1
        if len(Human_Terrain) == count:
            return float('nan')
        else:
            return np.nanmin(Human_Terrain)

    # find higher value X2
    def higher_HT(Human_Terrain):
        count=0
        for _ in Human_Terrain:
            if isnan(_)  == True:    #sitodos los elementos de la variable son nan
                count +=1
        if len(Human_Terrain) == count:
            return float('nan')
        else:
            return np.nanmax(Human_Terrain)

    _row_headers = ['Range', 'P_threat', 'Pno_threat', 'Q_threat', 'Qno_threat', 'px', 'qx', 'sp', 'sq', 'S']
    Threshold_value = []
    k = 0

    for _ht in Human_Terrain:
        table = BeautifulTable()

        k = k + 1
        #print('Human terrain Number: %d' % k)  # %d for decimal

        _min = float32(lower_HT(_ht))
        _max = float32(higher_HT(_ht))


    # calculation of the segment value x
        x = float32((_max - _min)) / 10  # float32 to obtain result with decimal,in this case (30-1)/10 = 2.9

        x = np.float32(x)
        xi = [x, 2 * x, 3 * x, 4 * x, 5 * x, 6 * x, 7 * x, 8 * x, 9 * x]   #todo x siempre va a ser 10?
        #print xi
        _cols = [_row_headers]
        S_array = []

        for _ in xi:  # for each range
            _col = []
            t = _ + _min
            _col.append('%f' % t)

    # Calculate Probability of threat in Sp region
            nx = 0  # total number of all samples (threat and no-threat) between the range [1,4]
            for outcomes in _ht:
                if math.isnan(outcomes) == False:
                    if outcomes <= _ + _min:
                        nx = np.float32 (nx + 1)
                else:
                    continue
            nn = nx

            nm = 0  # number of outcomes class samples located between [1,4]
            for i in index_T_class:
                # for outcomes in _ht[:21]:
                if math.isnan(_ht[i]) == False:
                    if _ht[i] <= _ + _min:
                        nm = nm + 1
                else:
                    continue


            if nx == 0:
                P_threat = 0
            else:
                P_threat = float32(nm) / nx
            _col.append('%d/%d' % (nm, nx))

    # Calculate Probability of no-threat in Sp Region
            nm = nx - nm

            if nx == 0:
                Pno_threat = 0
            else:
                Pno_threat = float32(nm) / nx
            _col.append('%d/%d' % (nm, nx))

    # Calculate Probability Threat is Sq Region
            nx = 0
            for outcomes in _ht:
                if math.isnan(outcomes) == False:
                    if outcomes > _ + _min:
                        nx = nx + 1
                else:
                    continue
            mm = nx
            mx = 0

            for i in index_T_class:
                # for outcomes in _ht[:21]:
                if math.isnan(_ht[i]) == False:
                    if _ht[i] > _ + lower_HT(_ht):
                        mx = mx + 1
                else:
                    continue

            Q_threat = 0
            if nx > 0:
                Q_threat = float32(mx) / nx
            _col.append('%d/%d' % (mx, nx))

    # Calculate Probability of no-threat in Sq Region
            mx = nx - mx
            Qno_threat = 0
            if nx > 0:
                Qno_threat = float32(mx) / nx
            _col.append('%d/%d' % (mx, nx))

            # ----------------------------------------

            px = float32(nn) / len(_ht)

            _col.append('%d/%d' % (nn, len(_ht)))

            qx = float32(mm) / len(_ht)  # mm is # of all samples in Sq (denominator of qthreat and qnothreat

            _col.append('%d/%d' % (mm, len(_ht)))

            # -----------------------------------
    # Calculate Entropy in Sp region
            Sp = 0
            if P_threat > 0:
                Sp = -(P_threat * math.log(P_threat)) + Sp
            if Pno_threat > 0:
                Sp = Sp + ((-Pno_threat) * math.log(Pno_threat))

            Sp = round(Sp, 3)
            _col.append('%f' % (Sp))

    # Calculate Entropy in Sq region
            Sq = 0
            if Q_threat > 0:
                Sq = -(Q_threat * math.log(Q_threat)) + Sq

            if Qno_threat > 0:
                Sq = Sq + ((-Qno_threat) * math.log(Qno_threat))

            Sq = round(Sq, 3)
            _col.append('%f' % Sq)

    # Calculate Entropy
            S = (px * Sp) + (qx * Sq)

            S = round(S, 3)
            S_array.append(S)

            _col.append('%f' % (S))

    # set threshold
            _col.append('')
            _cols.append(_col)

        _cols_transpose = [[r[col] for r in _cols] for col in range(len(_cols[0]))]

        _threshold_arr = [''] * len(_cols_transpose[0])
        _threshold_arr[0] = 'Threshold'

        min_entropy = min(S_array)

        S_array.insert(0, 'S')
        y = min_entropy
        threshold_index = []

        for _ in range(1, len(S_array)):
            if y == S_array[_]:
                threshold_index.append(_)

        for _ in threshold_index:
            _threshold_arr[_] = 'X'
        #print "threshold_index", threshold_index

        if len(threshold_index) == 1:
            threshold = round(((xi[threshold_index[0] - 1]) + _min), 2)
            Threshold_value.append(threshold)

        if len(threshold_index) > 1:
            ii = 0
            jj = 0
            while ii < len(threshold_index) - 1:
                if threshold_index[ii]+1 == threshold_index[ii + 1]:
                    jj = jj + 1
                ii = ii + 1
            if ii == jj:

                if  threshold_index[len(threshold_index) - 1] == len(xi):
                    threshold = round(((xi[threshold_index[0] - 1]) + _min), 2)
                    Threshold_value.append(threshold)

                elif threshold_index[0] == (len(xi) + 1) - len(xi):
                    threshold = round(((xi[threshold_index[len(threshold_index) - 1]-1]) + _min), 2)
                    Threshold_value.append(threshold)

                elif threshold_index[len(threshold_index)-1] != len(xi) and threshold_index[0] != (len(xi) + 1) - len(xi):
                    #temp = []
                    #for _ in threshold_index:
                    #    temp.append(xi[_-1])
                    #threshold = round(np.median(temp), 2)   #todo cambiar
                    #Threshold_value.append(threshold)
                    #print len(threshold_index)
                    if len(threshold_index) % 2  == 0:   #if len is even
                        threshold = round(xi[len(threshold_index)/2])
                        Threshold_value.append(threshold)
                    else:
                        threshold = round(xi[(len(threshold_index) / 2)]+ 0.5,2)
                        Threshold_value.append(threshold)
            else:
                if len(threshold_index) %2 == 0:
                    threshold = round(xi[len(threshold_index) / 2])

                    Threshold_value.append(threshold)
                else:
                    threshold = round(xi[(len(threshold_index) / 2)] + 0.5, 2)
                    Threshold_value.append(threshold)


        _cols_transpose.append(_threshold_arr)

        for _ in _cols_transpose:
            table.append_row(_)
        #print(table)
        #print " "

    #cadena_3 = "Threshold Value for all HT Variables".capitalize()
    #print cadena_3.center(76, "=")
    #print " "

    table = BeautifulTable()
    #table.append_row(["HT variables", "HT 0", "HT 1", "HT 2", "HT 3", "HT 4", "HT 5", "HT 6"])

    #row_t_h = []
    #row_t_h.append("HT variables")
    #i=0
    #while i <= len(Human_Terrain)-1:
     #   row_t_h.append("HT %d" %i)  # %d for decimal
      #  i += 1
    #row_t_h.append("Class")

    table.append_row(["HT variables", "HT 0", "HT 1", "HT 2", "HT 3", "HT 4", "HT 5", "HT 6", "HT 7", "HT 8", "HT9", "HT 10", "HT 11", "HT 12", "HT 13", "HT 14", "HT 15", "HT 16"])


    Threshold_value.insert(0, 'Threshold')
    #print Threshold_value
    table.append_row(Threshold_value)
    #print table
    Threshold_value.pop(0)       #delete 1st element(string) to calculate binary data correctly
    #print " "

    #print table

    #print len(Human_Terrain)
    #print len(Threshold_value)

    #cadena_3 = "Binary 1/0 Table for the HT Sample Data".capitalize()
    #print cadena_3.center(76, "=")
    #print " "

    #Human Terrain Sample Data Binary Conversion
    i = 0
    Binary_HT = []
    while i <= len(Threshold_value)-1:
        Binary_Human_Terrain = []
        for _ in Human_Terrain[i]:
            if math.isnan(_) == False:
                if _ <= Threshold_value[i]:
                    Binary_Human_Terrain.append(0)
                else:
                    Binary_Human_Terrain.append(1)
            else:
                Binary_Human_Terrain.append(_)
        Binary_HT.append(Binary_Human_Terrain)
        i+=1

    table = BeautifulTable()

    _cols = [No_data]
    #print Binary_HT
    for _ht in Binary_HT:
        _col = []
        for _ in _ht:
            _col.append(_)
        _cols.append(_col)

    _cols.append(binary_class)

    _cols_transpose = [[r[col] for r in _cols] for col in range(len(_cols[0]))]

    #table.append_row(row_h)
    table.append_row(["No.", "HT 0", "HT 1", "HT 2", "HT 3", "HT 4", "HT 5", "HT 6", "HT 7", "HT 8", "HT9", "HT 10", "HT 11", "HT 12", "HT 13", "HT 14", "HT 15", "HT 16", "Class"])

    for _col in _cols_transpose:
        #print _col
        table.append_row(_col)
    #print(table)

