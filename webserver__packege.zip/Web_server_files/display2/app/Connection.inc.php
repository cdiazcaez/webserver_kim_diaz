
<?php

/* If it has a .php extension the source
  code will not be visible. */

class Connection {

    private static $connection;  //objeto

    public static function open_connection() {
        //verificar si hay conexion
        //self conneccion desde aqui, connection::connection desde afuera
        //crear dos metodos, para abrir connection y cerrar
        //comprobar si hay conecxion o no
        //! is negar, isset nos da un valor boolean,
        if (!isset(self::$connection)) {  // si no hay connection...
            //abrir connection pueden haber muchos problemas, puede fallar
            //usamos try cathc, le decimos a  php que haga algo, si no puede, le decimos que hacer
            try {
                include_once 'config.inc.php';
                // esto es como coger el codigo de ese file y pegarlo aqui dentro
                // se pueden trabajar mejor, con codigos en pezados
                //tenemos dos drivers
                //mysqli & pdo
                //pdo trabaja como con 20 database distintos

                self::$connection = new PDO("mysql:host=$server_name;dbname=$database_name", $user_name, $password); // iniciar connection
                self::$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  //que por default PDO nos muestre los erres con el db, sino no lo hace
                //self::$connection -> exec("SET CHARACTER SET utf8") ;     
                //print "CONNECTION OPEN" . "<br>";
            } catch (PDOException $ex) {
                print "ERROR:" . $ex->getMessage() . "<br>";
                die();
            }
        }
    }

    public static function end_connection() {
        if (isset(self::$connection)) {  //comprobar si la conexion is active
            self::$connection = null;
            // print "CONNECTION CLOSED";
        }
    }

    public static function get_connection() {   //para conecctar por ej con connection::connection, 
        //connection fuera de esta clase
        return self::$connection;
    }

}
