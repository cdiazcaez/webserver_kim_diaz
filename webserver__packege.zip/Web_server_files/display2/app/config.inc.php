<?php

/* archivo de configuracion llamado config
 * archivos inc seran incluidos en otros files, pero los servidores 
 * leen files php. 
 * archivo inc podria mostrarse en texto y robar info de ususarios. 
 * 
 */
/* para definir una variable en php se usa $ */

$server_name = 'localhost';
$user_name = 'root';
$password = '';
$database_name = 'humanterrain';
?>