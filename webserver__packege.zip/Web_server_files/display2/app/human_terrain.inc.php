
<?php

/* crear una clase u objeto object oriented
 */

class Users {

    private $id;
    private $H0;
    private $H1;
    private $H2;
    private $H3;
    private $H4;
    private $H5;
    private $H6;

    public function __construct($id, $H0, $H1, $H2, $H3, $H4, $H5, $H6) {
        $this->id = $id;
        /* se usa this para decir que id es el mismo que el de la clase users, si no, 
         * seria un nuevo id
         */
        $this->H0 = $H0;
        $this->H1 = $H1;
        $this->H2 = $H2;
        $this->H3 = $H3;
        $this->H4 = $H4;
        $this->H5 = $H5;
        $this->H6 = $H6;
    }

    /* getters and setters */

    //getters
    public function obtener_id() {
        return $this->id;
    }

    public function obtener_H0() {
        return $this->H0;
    }

    public function obtener_H1() {
        return $this->H1;
    }

    public function obtener_H2() {
        return $this->H2;
    }

    public function obtener_H3() {
        return $this->H3;
    }

    //setters

    /* public function change_name($nombre){
      $this-> nombre = $nombre;
      }
      public function change_email($email){
      $this -> email = $email;
      }

      public function change_passworld($password){
      $this -> password = $password;
      }

      public function change_activo($activo){
      $this -> activo = $activo;
      } */
}
