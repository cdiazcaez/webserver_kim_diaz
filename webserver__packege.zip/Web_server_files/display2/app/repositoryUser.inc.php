<?php

/* trabaja con usuario
 * cada clase que se vaya a usar con una tabla del database tiene su propio repository
 * por ejemplo, repcuperar todos los usuarios, recuperar todos los users activos
 * o recuperar el user con el id 127
 * usamos metodos estaticos, 
 */

class RepositoryUser {

    //crear function para obtener todos los users en la tabla de usuarios del db

    public static function get_all($connection) { //se indica en el argumento usaremos una connection
        $users = array(); // donde guardaremos los usuarios 
        //verificar si hay connection

        if (isset($connection)) {
            // usamos el bloque try catch
            try {
                include_once 'user.inc.php';
                //crear variable sql, para crear variable se usa $
                //sql otro lenguaje
                //SELECT, asterisco es para select all, FROM users es de que tabla del DB
                $sql = "SELECT * FROM users";  //SQL LANGUAGE
                // trabajando con pdo creamos la variable sentencia, statement
                $stmt = $connection->prepare($sql);  // esto se hace por, por ej "injection sql" que es un error donde alguien puede escribir una combinacion de ca
                //caracteres que cuando la instruccion sql se ejecuta devuelva a la pagina cualquier info que el user quiera.
                //esto se evita "escapando de los caracteres", que los caracteres no tengan sendido de programacion, prepare lo  hace de forma automatica. 
                $stmt->execute();
                $result = $stmt->fetchAll(); //le pedimos a la sentencia nos devuelva todos los resultados existentes
                //result sera un arreglo
                //puede que no haya resultado, tabla vacia, usamos count para saber
                if (count($result)) {
                    //foreach, recorre todo el arreglo, el arreglo results 
                    foreach ($result as $row) {
                        //el indice del arreglo user [] que lo vaya recorriendo
                        //tenemos ahora que que añadir los nuevos objetos al constructor en user.inc.php
                        $users[] = new users(
                                $row['id'], $row['nombre'], $row['email'], $row['password'], $row['fecha_registro'], $row['activo']
                        );
                    }
                } else {
                    print 'User list empty';
                }
            } catch (PDOException $ex) {
                print "ERROR" . $ex->getMessage();
            }
        }
        return $users;
    }

    //saber cuantos usarios tengo de manera mas eficiente
    // la clase de arriba guarda todos los usuarios en un array y despues te dice el lenght
    // si tenemos por ej 1 millon de usuarios, no es efieciente guardarlos todos para contar, ademas de que esforzamos al server
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public static function get_all_users($connection) {
        $total_users = null;

        //como siempre confirmar primero si hay coneccion con try catch
        if (isset($connection)) {
            try {
                $sql = "SELECT COUNT(*) as total FROM users"; // total es para referencia, cuando llame a 'totat'nos dira el resultado, puedo llamarlo como quiera
                $stmt = $connection->prepare($sql);
                $stmt->execute();
                $result = $stmt->fetch();

                $total_users = $result['total'];
            } catch (PDOException $ex) {
                print 'ERROR' . $ex->getMessage();
            }
        }

        return $total_users;
    }

}
