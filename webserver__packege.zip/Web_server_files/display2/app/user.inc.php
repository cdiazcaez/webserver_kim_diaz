<?php

class User {

    private $id;
    private $nombre;
    private $email;
    private $password;
    private $fecha_registro;
    private $activo;

    public function __construct($id, $nombre, $email, $password, $fecha_registro, $activo) {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->email = $email;
        $this->password = $password;
        $this->fecha_registro = $fecha_registro;
        $this->activo = $activo;
    }

    //getters y setters
    //nuestras variables son privabas, no podremos verlas
    //public funtion nos dejara ver su valor,no cambiarlo
    //getters
    public function get_id() { //// public function nos dejara llamar la funcion fuera de este file
        return $this->id;
    }

    public function get_name() {
        return $this->nombre;
    }

    public function get_password() {
        return $this->password;
    }

    public function get_email() {
        return $this->email;
    }

    public function get_registration_date() {
        return $this->fecha_registro;
    }

    public function get_active() {    // es boleano, actico sera cero o uno, activo o no
        return $this->activo;
    }

    //setteers  nos dejara cambiar el valor, por ej el usuario quiere cambiar su nombre o email

    public function set_name($nombre) {
        $this->nombre = $nombre;
    }

    public function set_email($email) {
        $this->email = $email;
    }

    public function set_password($password) {
        $this->password = $password;
    }

    public function set_active($activo) {
        $this->activo = $activo;
    }

}
