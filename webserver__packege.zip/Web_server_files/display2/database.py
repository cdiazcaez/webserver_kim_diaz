# import MySQLdb << Remove this line and replace with:
#import pymysql
#pymysql.install_as_MySQLdb()

#call my python file from a php
import mysql.connector
import numpy as np

from beautifultable import BeautifulTable

from numpy import *
import math

cnx = mysql.connector.connect(host='localhost',
                             user='root',
                             password='',
                             database='humanterrain')

try:
    cursor = cnx.cursor()
    cursor.execute("SELECT * FROM `htvariables`")
    result = np.array(cursor.fetchall())
    #print range(len(result))
    #for _ in range(len(result)):
     #   del result[_][0]
    result = np.delete(result, (0), axis=1)
    #print result
    #for _ in result:
     #   print _
    #print type(result)
finally:
    cnx.close()
#Student: Christian Diaz, ID: @02869687
#Advisor: Dr. Charles Kim


# for row in Human_Terrain:
#    print (row)

Human_Terrain_temp = np.transpose(result)
#print Human_Terrain

# Declare Human Terrain variables as lists

def str_to_num(array):
    for q, p in enumerate(array):
        if p == '0':
            array[q] = 0

    for q, p in enumerate(array):
        if p == '1':
            array[q] = 1
    return

#print type(Human_Terrain[0][0])

#for _ in Human_Terrain:
 #   str_to_num(_)

Human_Terrain = []
#for d in Human_Terrain_temp:
 #   for _ in d:
    #     print _

for _ in Human_Terrain_temp:
    a = []
    for d in _:
        a.append(float(d))
    Human_Terrain.append(a)

Human_Terrain_0 = Human_Terrain[0]
Human_Terrain_1 = Human_Terrain[1]
Human_Terrain_2 = Human_Terrain[2]
Human_Terrain_3 = Human_Terrain[3]
Human_Terrain_4 = Human_Terrain[4]
Human_Terrain_5 = Human_Terrain[5]
Human_Terrain_6 = Human_Terrain[6]

print "hooooooooooo", Human_Terrain


# print (Human_Terrain[0][0])
print Human_Terrain

# Assign threat class for each outcomes

table_samples = BeautifulTable()
sample_class = []  # blank array where we will to assign a threat class value to each HT outcome.
cadena = "Enumerated HT data samples".capitalize()
print " "
print cadena.center(76, "=")
print " "

Data_no = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]    #loop lenght HT

_cols = [Data_no]

for _ht in Human_Terrain:
    _col = []
    for _ in _ht:
        _col.append(_)
    _cols.append(_col)

for outcomes in Human_Terrain_0[:21]:
    sample_class.append(1)

for _ in Human_Terrain_0[-10:]:
    sample_class.append(0)

_cols.append(sample_class)

_cols_transpose = [[r[col] for r in _cols] for col in range(len(_cols[0]))]

table_samples.append_row(["No.", "HT variable 0", "HT variable 1", "HT variable 2", "HT variable 3", "HT variable 4", "HT variable 5", "HT variable 6", "Class"])

for _col in _cols_transpose:
    table_samples.append_row(_col)
print(table_samples)

print " "
cadena_2 = "Threshold Value Calculation for all HT variales".capitalize()
print cadena_2.center(76, "=")
print " "

# find lower value X1
def lower_HT(Human_Terrain):
    return min(Human_Terrain)

# find higher value X2
def higher_HT(Human_Terrain):
    return max(Human_Terrain)

_row_headers = ['Range', 'P_threat', 'Pno_threat', 'Q_threat', 'Qno_threat', 'px', 'qx', 'sp', 'sq', 'S']
Threshold_value = []
i = 0

for _ht in Human_Terrain:
    table = BeautifulTable()

    i = i + 1
    print('Human terrain Number: %d' % i)  # %d for decimal

    _min = float(lower_HT(_ht))
    _max = float(higher_HT(_ht))

# calculation of the segment value x
    x = float((_max - _min)) / 10  # float to obtain result with decimal,in this case (30-1)/10 = 2.9

    x = np.float32(x)
   # if _ht == Human_Terrain_2 or _ht == Human_Terrain_5 or _ht == Human_Terrain_6:  #if HT hava float outcomes
    #    x = round(x, 3)
   # else:
   #     x = round(x)

    print "x:", x
    xi = [x, 2 * x, 3 * x, 4 * x, 5 * x, 6 * x, 7 * x, 8 * x, 9 * x]

  #  print "check"
   # print "x:", x

    for _ in xi:
        print _ + x


    _cols = [_row_headers]
    S_array = []

    for _ in xi:  # for each range
        _col = []
        t = _ + _min
        _col.append('%f' % t)

# Calculate Probability of threat in Sp region
        nx = 0  # total number of all samples (threat and no-threat) between the range [1,4]
        for outcomes in _ht:
            if outcomes <= _ + _min:
                nx = np.float32 (nx + 1)
        nn = nx

        nm = 0  # number of outcomes class samples located between [1,4]
        for outcomes in _ht[:21]:
            if outcomes <= _ + _min:
                nm = nm + 1
        P_threat = float(nm) / nx

        _col.append('%d/%d' % (nm, nx))

# Calculate Probability of no-threat in Sp Region
        nm = nx - nm
        Pno_threat = float(nm) / nx

        _col.append('%d/%d' % (nm, nx))

# Calculate Probability Threat is Sq Region
        nx = 0
        for outcomes in _ht:
            if outcomes > _ + _min:
                nx = nx + 1
        mm = nx
        mx = 0

        for outcomes in _ht[:21]:
            if outcomes > _ + lower_HT(_ht):
                mx = mx + 1

        Q_threat = 0
        if nx > 0:
            Q_threat = float(mx) / nx

        _col.append('%d/%d' % (mx, nx))

# Calculate Probability of no-threat in Sq Region
        mx = nx - mx
        Qno_threat = 0
        if nx > 0:
            Qno_threat = float(mx) / nx

        _col.append('%d/%d' % (mx, nx))

        # ----------------------------------------

        px = float(nn) / len(_ht)

        _col.append('%d/%d' % (nn, len(_ht)))

        qx = float(mm) / len(_ht)  # mm is # of all samples in Sq (denominator of qthreat and qnothreat

        _col.append('%d/%d' % (mm, len(_ht)))

        # -----------------------------------
# Calculate Entropy in Sp region
        Sp = 0
        if P_threat > 0:
            Sp = -(P_threat * math.log(P_threat)) + Sp
        if Pno_threat > 0:
            Sp = Sp + ((-Pno_threat) * math.log(Pno_threat))

        Sp = round(Sp, 3)

        _col.append('%f' % (Sp))

# Calculate Entropy in Sq region
        Sq = 0
        if Q_threat > 0:
            Sq = -(Q_threat * math.log(Q_threat)) + Sq

        if Qno_threat > 0:
            Sq = Sq + ((-Qno_threat) * math.log(Qno_threat))

        Sq = round(Sq, 3)
        _col.append('%f' % Sq)

# Calculate Entropy
        S = (px * Sp) + (qx * Sq)

        S = round(S, 3)
        S_array.append(S)

        _col.append('%f' % (S))

# set threshold
        _col.append('')
        _cols.append(_col)

    _cols_transpose = [[r[col] for r in _cols] for col in range(len(_cols[0]))]

    _threshold_arr = [''] * len(_cols_transpose[0])
    _threshold_arr[0] = 'Threshold'

    min_entropy = min(S_array)

    S_array.insert(0, 'S')
    y = min_entropy
    threshold_index = []

    for _ in range(1, len(S_array)):
        if y == S_array[_]:
            threshold_index.append(_)

    for _ in threshold_index:
        _threshold_arr[_] = 'X'

# for _ in threshold_index:
    if threshold_index[len(threshold_index) - 1] == len(xi) and len(threshold_index) > 1:
            threshold = round(((xi[threshold_index[0] - 1]) + _min), 2)
            Threshold_value.append(threshold)

    if threshold_index[0] == (len(xi) + 1) - len(xi) and len(threshold_index) > 1:
        threshold = round(((xi[threshold_index[len(threshold_index) - 1]-1]) + _min), 2)
        Threshold_value.append(threshold)

    if len(threshold_index) == 1:
        threshold = round(((xi[threshold_index[0] - 1]) + _min), 2)
        Threshold_value.append(threshold)

    _cols_transpose.append(_threshold_arr)

    for _ in _cols_transpose:
        table.append_row(_)
    print(table)
    print " "


cadena_3 = "Threshold Value for all HT Variables".capitalize()
print cadena_3.center(76, "=")
print " "

table = BeautifulTable()
table.append_row(["HT variables", "HT 1", "HT 2", "HT 3", "HT 4", "HT 5", "HT 6", "HT 7"])

Threshold_value.insert(0,'Threshold')
table.append_row(Threshold_value)
print table
Threshold_value.pop(0)       #delete 1st element(string) to calculate binary data correctly
print " "


cadena_3 = "Binary 1/0 Table for the HT Sample Data".capitalize()
print cadena_3.center(76, "=")
print " "


#Human Terrain Sample Data Binary Conversion

Binary_Human_Terrain_0 = []
Binary_Human_Terrain_1 = []
Binary_Human_Terrain_2 = []
Binary_Human_Terrain_3 = []
Binary_Human_Terrain_4 = []
Binary_Human_Terrain_5 = []
Binary_Human_Terrain_6 = []

Binary_HT = [Binary_Human_Terrain_0, Binary_Human_Terrain_1, Binary_Human_Terrain_2, Binary_Human_Terrain_3, Binary_Human_Terrain_4, Binary_Human_Terrain_5, Binary_Human_Terrain_6]

table = BeautifulTable()

for _ in Human_Terrain_0:
    if _ <= Threshold_value[0]:
        Binary_Human_Terrain_0.append(0)
    else:
        Binary_Human_Terrain_0.append(1)


for _ in Human_Terrain_1:
    if _ <= Threshold_value[1]:
        Binary_Human_Terrain_1.append(0)
    else:
        Binary_Human_Terrain_1.append(1)


for _ in Human_Terrain_2:
    if _ <= Threshold_value[2]:
        Binary_Human_Terrain_2.append(0)
    else:
        Binary_Human_Terrain_2.append(1)

for _ in Human_Terrain_3:
    if _ <= Threshold_value[3]:
        Binary_Human_Terrain_3.append(0)
    else:
        Binary_Human_Terrain_3.append(1)

for _ in Human_Terrain_4:
    if _ <= Threshold_value[4]:
        Binary_Human_Terrain_4.append(0)
    else:
        Binary_Human_Terrain_4.append(1)

for _ in Human_Terrain_5:
    if _ <= Threshold_value[5]:
        Binary_Human_Terrain_5.append(0)
    else:
        Binary_Human_Terrain_5.append(1)

for _ in Human_Terrain_6:
    if _ <= Threshold_value[6]:
        Binary_Human_Terrain_6.append(0)
    else:
        Binary_Human_Terrain_6.append(1)


No_data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]

_cols = [No_data]

for _ht in Binary_HT:
    _col = []
    for _ in _ht:
        _col.append(_)
    _cols.append(_col)

binary_class = []

for outcomes in Human_Terrain_1[:21]:
    binary_class.append("Threat")

for outcomes in Human_Terrain_1[-10:]:
    binary_class.append("No-Treat")

_cols.append(binary_class)

_cols_transpose = [[r[col] for r in _cols] for col in range(len(_cols[0]))]

table.append_row(["Data No.", "HT variable 0", "HT variable 1", "HT variable 2", "HT variable 3", "HT variable 4", "HT variable 5", "HT variable 6", "Class"])

for _col in _cols_transpose:
    table.append_row(_col)
print(table)

#todo SPRING 2018 #############################################################################################################################################################################




#Conditional Probability of Threat


_row_headers = ['fi(1|T)', 'fi(0|NT)', 'fi', 'Ii']
_cols = [_row_headers]

table = BeautifulTable()
table.append_row([" ", 'HT variable 0', 'HT variable 1', 'HT variable 2', 'HT variable 3', 'HT variable 4', 'HT variable 5', 'HT variable 6' ])

Ii_array = []
for _ in Binary_HT :
    _col = []

    freq_T = _[:21].count(1)


    #print freq_T
    _col.append('%d/%d' % (freq_T, 21))

    freq_NT = _[-10:].count(0)

    _col.append('%d/%d' % (freq_NT, 21))

    print "Frequency Threat:", freq_T, "/", 21
    print "Frequency No Threat:", freq_NT, "/", 10

    fi = (freq_T / 21.0) + (freq_NT / 10.0)
    _col.append('%f' % fi)

    print "fi:" ,  fi

    Ii = abs(fi - 1)
    Ii = round(Ii, 3)
    Ii_array.append(Ii)

    _col.append('%f' % Ii)
    print "Ii"

    _cols.append(_col)

_cols_transpose = [[r[col] for r in _cols] for col in range(len(_cols[0]))]


_attribute_arr = [''] * len(_cols_transpose[0])
_attribute_arr = ['Selected Attribute']


h = max(Ii_array)

Ii_array.insert(0, 'Ii')


print "h", h

#Saving HT index to find the HT with wich we will cacalculate 4 conditional probabilities.
HT_index = []


for _ in range(1, len(Ii_array)):
    if h == Ii_array[_]:
        _attribute_arr.append('X')
        HT_index.append(_ - 1)
    else:
        _attribute_arr.append('')

print _attribute_arr
_cols_transpose.append(_attribute_arr)

for _ in _cols_transpose:
    table.append_row(_)
print(table)
print " "

for _ in _cols_transpose:
    table.append_row(_)

####### four conditional probabilities

#Best attribute is selected from HT variable 4   ### arreglar principio codigo HT variables comeinzan en HT var 1

#Conditional probability of T and NT given cero



T_given_cero = float(Binary_HT[HT_index[0]][:21].count(0)) / Binary_HT[HT_index[0]].count(0)    # todo CAMBIAR VAR 5 POR 4

print "T_given_cero:", Binary_HT[HT_index[0]][:21].count(0), "/", Binary_HT[HT_index[0]].count(0)

NT_given_cero = float(Binary_HT[HT_index[0]][-10:].count(0)) / Binary_HT[HT_index[0]].count(0)

print "NT_given_cero:" , Binary_HT[HT_index[0]][-10:].count(0), "/ ", Binary_HT[HT_index[0]].count(0)

#Conditional probability of T and NT given one

T_given_one = float(Binary_HT[HT_index[0]][:21].count(1)) / Binary_HT[HT_index[0]].count(1)    # todo CAMBIAR VAR 5 POR 4
print "T_given_one:", Binary_HT[HT_index[0]][:21].count(1), "/", Binary_HT[HT_index[0]].count(1)    # todo CAMBIAR VAR 5 POR 4


NT_given_one = float(Binary_HT[HT_index[0]][-10:].count(1)) / Binary_HT[HT_index[0]].count(1)
print "NT_given_one:", Binary_HT[HT_index[0]][-10:].count(1), "/", Binary_HT[HT_index[0]].count(1)

table_cond_prob = BeautifulTable()
table_cond_prob.append_row(['p4(T|0)','p4(NT|0)', 'p4(T|1)','p4(NT|1)'])
_col_cp = []

#Binary_HT[HT_index[0]][:21]
_col_cp.append('%d/%d' %(Binary_HT[HT_index[0]][:21].count(0), Binary_HT[HT_index[0]].count(0)))
_col_cp.append('%d/%d' %(Binary_HT[HT_index[0]][-10:].count(0), Binary_HT[HT_index[0]].count(0)))
_col_cp.append('%d/%d' %(Binary_HT[HT_index[0]][:21].count(1), Binary_HT[HT_index[0]].count(1)))
_col_cp.append('%d/%d' %(Binary_HT[HT_index[0]][-10:].count(1), Binary_HT[HT_index[0]].count(1)))

table_cond_prob.append_row(_col_cp)

#Finding highest conditional probability to build the rule pattern

_max_prob = []
_con_prob_arr = [T_given_cero, NT_given_cero, T_given_one, NT_given_cero]

_cp_max = max(_con_prob_arr)

for _ in range(len(_con_prob_arr)):
    if _cp_max == _con_prob_arr[_]:
        _max_prob.append('R: A'+ str(HT_index[0]) + ' = 0 ---> T')    #todo ########## cambiar la T para cuando sea NT
    else:
        _max_prob.append('')

table_cond_prob.append_row(_max_prob)

print table_cond_prob


print " "
cadena_2 = "Unbiased Probability".capitalize()
print cadena_2.center(76, "=")
print " "

p = float(Binary_HT[HT_index[0]][:21].count(0) +1) / (Binary_HT[HT_index[0]].count(0) +2)
p = round(p,3)
print "<p>:", Binary_HT[HT_index[0]][:21].count(0) +1, "/", Binary_HT[HT_index[0]].count(0) +2,"=", p

#margin error
print " "
cadena_2 = "Margin of Error".capitalize()
print cadena_2.center(76, "=")
print " "


e_margin = float(p*(1-p))/(Binary_HT[HT_index[0]].count(0) +2)
e_margin = round(e_margin,4)



print "ek(T|0):", round((p*(1-p)),3),"/",(Binary_HT[HT_index[0]].count(0) +2), "=", e_margin

print " "
print " "
##

#FALTA CODIGO todo todo del todo hahahahahahahahahahahahahahahahahahahahahaha se feliz

###

#hacer loop porque tambien puede ser cuando sea 1

#puede ser un if que
#T NT T NO
#0 1 2 3
# IF 0 OR 2 BORRA LOS CERO, VERIFICAR SI ES ASI



arr = []

for _ in range(len(Binary_Human_Terrain_0)):

    if Binary_Human_Terrain_4[_] == 1:
        arr.append(_)
print "arr:", arr

_new_table = BeautifulTable()
_new_table.append_row(["Data No.", "HT variable 0", "HT variable 1", "HT variable 2", "HT variable 3", "HT variable 4", "HT variable 5", "HT variable 6", "Class"])
_cols = []

_new_nodata = []
for _ in arr:
    _new_nodata.append(No_data[_])

_cols.append(_new_nodata)

for ht in Binary_HT:
    _new_HT = []
    for _ in arr:
        _new_HT.append(ht[_])
    _cols.append(_new_HT)
    print _new_HT


_new_binaryclass = []

for _ in arr:
    _new_binaryclass.append(binary_class[_])

_cols.append(_new_binaryclass)

_cols_transpose = [[r[_new_HT] for r in _cols] for _new_HT in range(len(_cols[0]))]


for _ in _cols_transpose:
    _new_table.append_row(_)
print(_new_table)


###################################################################################################################################################3



#import pandas as pd
#from sklearn import tree


No_data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
           30, 31]  # loop lenght HT
#Binary_HT = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0],
 #            [1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1],
 #            [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0],
  #           [0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0],
   #          [1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    #         [0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
     #        [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1]]

binary_class = ['Threat', 'Threat', 'Threat', 'Threat', 'Threat', 'Threat', 'Threat', 'Threat', 'Threat', 'Threat',
                'Threat', 'Threat', 'Threat', 'Threat', 'Threat', 'Threat', 'Threat', 'Threat', 'Threat', 'Threat',
                'Threat', 'No-Threat', 'No-Threat', 'No-Threat', 'No-Threat', 'No-Threat', 'No-Threat', 'No-Threat',
                'No-Threat', 'No-Threat', 'No-Threat']

data = []

data.append(Data_no)

for _ in Binary_HT:
    data.append(_)

data = append(data, [binary_class], 0)

data_transpose = [[data[j][i] for j in range(len(data))] for i in range(len(data[0]))]

for _ in data_transpose:
    print _

def arguments_table(data_transpose):

    num_row = len(data_transpose)
    num_col = len(data_transpose[0])

    index_1 = len(data_transpose[0]) - (len(data_transpose[0]) - 1)  # from table(index 1st HT
    # index 0 is No_data, index 1 is 1st HT

    index_2 = len(data_transpose[0]) - 2  # until index last HT
    # we have 9 column, last column is index 8(class column)
    # index seven is our last HT

    # data_transpose[0] COLUMNAS 9 todo

    freq_T_class = 0  # frequency threat    #viene siendo el 21 del 1/21
    freq_NT_class = 0

    for i in range(len(data_transpose)):  # separate concern
        if data_transpose[i][index_2 + 1] == "Threat":
            freq_T_class += 1
        else:
            freq_NT_class += 1

    # function to replace elements (string '0' and '1' for 0 and 1
    def str_to_num(array):
        for q, p in enumerate(array):
            if p == '0':
                array[q] = 0

        for q, p in enumerate(array):
            if p == '1':
                array[q] = 1
        return

    # working with Threat class

    fi_T = []  # conditional (1|T)
    fi_NT = []  # conditional (0|NT)
    fi = []  # sum of fi_T and fi_NT
    I = []  # index attribute
    select_att = []

    for i in range(1, num_col - 1):
        ht_values_tclass = []
        ht_values_ntclass = []

        for _ in range(freq_T_class):
            b = (data_transpose[_][i])
            ht_values_tclass.append(b)

        str_to_num(ht_values_tclass)
        freq_T_ht = ht_values_tclass.count(1) #viene siendo el 1 del 1/21


        if freq_T_class > 0:  # todo###############################
            global fi_value
            fi_value = float(freq_T_ht) / freq_T_class
            fi_value = round(fi_value, 4)
        elif freq_T_class == 0:
            fi_value = 0


        fi_T.append(fi_value)

        # NO THREAT
        for _ in range(freq_T_class, len(data_transpose)):
            b = (data_transpose[_][i])
            ht_values_ntclass.append(b)

        str_to_num(ht_values_ntclass)

        freq_NT_ht = ht_values_ntclass.count(0)

        fi_value_NT = float(freq_NT_ht) / freq_NT_class
        # print freq_NT_ht, "/", freq_NT_class
        fi_value_NT = round(fi_value_NT, 4)
        fi_NT.append(fi_value_NT)

    for _ in range(len(fi_T)):
        sum = fi_T[_] + fi_NT[_]
        sum = round(sum, 2)
        fi.append(sum)


    for _ in range(len(fi)):
        sum = abs(fi[_] - 1)
        sum = round(sum, 2)
        I.append(sum)

    attribute = max(I)
    #  print attribute

    for _ in range(len(I)):
        if I[_] == attribute:
            # location_att = location_att + _ + 1
            select_att.append("X")
        else:
            select_att.append(" ")
    #print select_att
    global location_att
    location_att = 0
    # print I

    for _ in range(len(select_att)):
        if select_att[_] == "X":
            location_att = _ + 1

    # print select_att
    # print location_att
    # print "fi_T", fi_T
    # print "fi_NT", fi_NT
    # print "fi", fi
    # print "I", I
    # print "select_att", select_att

    HT_max_att = []  # is the HT with the max att to use in the 4 conditional probabilites calculation
    for _ in range(len(data_transpose)):
        b = data_transpose[_][location_att]
        HT_max_att.append(b)
        str_to_num(HT_max_att)

    ######################
    # conditional prob. T fiven 0


    conditional_array = []
    conditional_array_num= []
    conditional_array_den = []

    if HT_max_att.count(0) > 0:
        T_given_cero = float(HT_max_att[:freq_T_class].count(0)) / HT_max_att.count(0)
        T_given_cero = round(T_given_cero, 2)
        conditional_array_num.append(HT_max_att[:freq_T_class].count(0))
        conditional_array_den.append(HT_max_att.count(0))


        NT_given_cero = float(HT_max_att[-freq_NT_class:].count(0)) / HT_max_att.count(0)
        NT_given_cero = round(NT_given_cero, 2)
        conditional_array_num.append(HT_max_att[-freq_NT_class:].count(0))
        conditional_array_den.append(HT_max_att.count(0))

        conditional_array.append(T_given_cero)
        conditional_array.append(NT_given_cero)

    elif HT_max_att.count(0) == 0:
        conditional_array.append(0)
        conditional_array.append(0)
        conditional_array_num.append(0)
        conditional_array_den.append(0)
        conditional_array_num.append(0)
        conditional_array_den.append(0)

    if HT_max_att.count(1) > 0:

        T_given_one = float(HT_max_att[:freq_T_class].count(1)) / HT_max_att.count(1)
        T_given_one = round(T_given_one, 2)
        conditional_array_num.append(HT_max_att[:freq_T_class].count(1))
        conditional_array_den.append(HT_max_att.count(1))

        NT_given_one = float(HT_max_att[-freq_NT_class:].count(1)) / HT_max_att.count(1)
        NT_given_one = round(NT_given_one, 2)
        conditional_array_num.append(HT_max_att[-freq_NT_class:].count(1))
        conditional_array_den.append(HT_max_att.count(1))

        conditional_array.append(T_given_one)
        conditional_array.append(NT_given_one)

    elif HT_max_att.count(1) == 0:
        conditional_array.append(0)
        conditional_array.append(0)
        conditional_array_num.append(0)
        conditional_array_den.append(0)
        conditional_array_num.append(0)
        conditional_array_den.append(0)

    #print conditional_array ##############################################################################################################################
    #print conditional_array_num
    #print conditional_array_den

    rule = max(conditional_array)
    select_rule = []
    #################################
    global a
    a = 0
    global u
    global bin_con
    u = 0    #saving the rule as a global to print at the final with all the steps rules
    bin_con = 0 #saving the binary condition (0 or 1) to test later the rules.
    for _ in range(len(conditional_array)):
        if conditional_array[_] == rule and _ == 0:
            u = 'R: A' + str(location_att - 1) + ' = 0 ---> T '
            select_rule.append(u)
            a = _
            bin_con = 0
        elif conditional_array[_] == rule and _ == 1:
            u = 'R: A' + str(location_att-1) + ' = 0 ---> NT'
            select_rule.append(u)
            a = _
            bin_con = 0
        elif conditional_array[_] == rule and _ == 2:
            u = 'R: A' + str(location_att-1) + ' = 1 ---> T '
            select_rule.append(u)
            a = _
            bin_con = 1
        elif conditional_array[_] == rule and _ == 3:
            u = 'R: A' + str(location_att-1) + ' = 1 ---> NT'
            select_rule.append(u)
            a = _
            bin_con = 1
        else:
            select_rule.append(" ")

    #print a
    #print select_rule

    #print " "

    global p
    p = 0
    if a == 0 or a == 1:
        p = 0

    elif a == 2 or a == 3:
        p = 1
       # print "Entro al p=1"

    # print len(data_transpose)
    # print location_att
    # print a
   # print _col
   # _cols_attribute.append(_col)


    #attribute table
    print " "
    cadena_2 = "Calculation of Attribute".capitalize()
    print cadena_2.center(76, "=")
    print " "

    table_attribute = BeautifulTable()
    table_attribute.append_row([" ", 'HT variable 0', 'HT variable 1', 'HT variable 2', 'HT variable 3', 'HT variable 4', 'HT variable 5',
         'HT variable 6'])

    fi_T.insert(0, 'fi(1|T)')
    table_attribute.append_row(fi_T)
    fi_NT.insert(0,'fi(0|NT)')
    table_attribute.append_row(fi_NT)
    fi.insert(0, 'fi')
    table_attribute.append_row(fi)
    I.insert(0, 'Ii')
    table_attribute.append_row(I)
    select_att.insert(0, 'selected att')
    table_attribute.append_row(select_att)
   # table_attribute[0].append_column([" ", 'fi(1|T)', 'fi(0|NT)', 'fi', 'Ii', "Selected Attribute"])

    print table_attribute
    print " "

    print " "
    cadena_2 = "Unbiased Probability".capitalize()
    print cadena_2.center(76, "=")
    print " "
    #Conditional Probabilities Table
    table_cond_prob = BeautifulTable()
    table_cond_prob.append_row(['p'+ str(location_att-1) + '(T|0)', 'p'+ str(location_att-1) + '(NT|0)', 'p'+ str(location_att-1) + '(T|1)', 'p'+ str(location_att-1) + '(NT|1)'])
    table_cond_prob.append_row(conditional_array)
    table_cond_prob.append_row(select_rule)

    print table_cond_prob
    print " "
    cadena_2 = "Margin of Error".capitalize()
    print cadena_2.center(76, "=")
    print " "


    for _ in range(len(conditional_array)):
        if conditional_array[_] == rule:
            global MEP
            MEP = float(conditional_array_num[_] + 1)/(conditional_array_den[_] + 2)
            MEP = round(MEP,2)
            print "Maximum Entropy Probability  <p>:", "%.2f" % MEP

            radicant = ((MEP)*(1-MEP))/(conditional_array_den[_] + 2)
            global ek
            ek = math.sqrt(radicant)*1.96
            ek = round(ek, 2)
            print "Margin of error ek:", "%.2f" % ek

           # print conditional_array_num[_]
            #print conditional_array_den[_]
            break

    return (p, location_att)
#print arguments_table(data_transpose)

_location_att = []
_binary_condition = []
_rule = []
_MEP = []
_error = []


def falu(data_temp):
    if len(data_temp) <> 0:
        print " "
        title = "Rule Extraction"
        title = title.upper()
        print  title.center(76, "*")
        arguments_table(data_temp)
        print '%d, %d' % (p,location_att)
       # print arguments_table(data_temp)
        _rule.append(u)
        _MEP.append(MEP)
        _error.append(ek)
        _location_att.append(location_att - 1)
        _binary_condition.append(bin_con)

        i = 0  # Lines Number
        j = len(data_temp)  # Column Number
        data_temp_2 = []  # New Table
        table = BeautifulTable()
        table.append_row(["Data No.", "HT variable 0", "HT variable 1", "HT variable 2", "HT variable 3", "HT variable 4", "HT variable 5", "HT variable 6", "Class"])
        #table.append_row(_row_headers)
        #print "data_temp_2 --> ", len(data_temp_2)
        while i < j:
            if data_temp[i][location_att] <> '%d' % p:
                data_temp_2.append(data_temp[i])
            i = i + 1
            if i == j and len(data_temp_2) == 0:
                break

        for _ in data_temp_2:
            table.append_row(_)
        print table

        #print data_temp_2
        if (j <> 0):
            falu(data_temp_2)  # Recursion


# Separation of Concern

falu(data_transpose)  # calling falu function

print " "

v = "*"
print  v.center(76, "*")

title = " Desicion-assist rule "
title = title.upper()
print  title.center(76, "*")

v = "*"
print  v.center(76, "*")
print(" ")

for _ in range(len(_rule)):
    num_step = _ + 1
    #print "Step" + num_step + ":" + _rule[_] + "with" + "<p>=" + _MEP[_] + "<e>=" + _error[_]
    print "Step", num_step, ":", _rule[_],  "with", "<p> =", "%.2f" % _MEP[_], "<e>=", "%.2f" % _error[_]

print ""

#print "testing rules..."





new_class= []

def testing_rules(row):
    global new_class
    new_class = 0
    global certein
    i = 0
    certein = 0
    while i < range(len(_rule)):
        if data_transpose[row][_location_att[i]+1] == '%d' %_binary_condition[i]:
            new_class = _rule[i]
            certein = _MEP[i]
            break
        else:
            i = i + 1
            continue

#print _rule[i]


new_class_arr = []

certein_arr = []

for _ in range(len(data_transpose)):
    testing_rules(_)
    new_class_arr.append(new_class)
    certein_arr.append(certein)

#print new_class_arr
#print certein_arr
print " "

new_table_w_rules = []
#new_table_w_rules.append(No_data)
for _ in data_transpose:
    new_table_w_rules.append(_)



for i in range(31):
    new_table_w_rules[i].append(new_class_arr[i])
    new_table_w_rules[i].append(certein_arr[i])

#for _ in new_table_w_rules:
 #   print _

table_class_rule = BeautifulTable()
table_class_rule.append_row(["Data No.", "HT variable 0", "HT variable 1", "HT variable 2", "HT variable 3", "HT variable 4",
                      "HT variable 5", "HT variable 6", "Class", "Rule",  "Confidende"])

for _ in new_table_w_rules:

    table_class_rule.append_row(_)

#print table_class_rule







"""
import pymysql.cursors
import pymysql
# Connect to the database
connection = pymysql.connect(host='localhost',
                         user='root',
                         password='',
                         db='humanterrain',

                         cursorclass=pymysql.cursors.DictCursor)

with connection.cursor() as cursor:
cur=connection.cursor()
cur.execute("SELECT * FROM `htvariables`")
for row in cur.fetchall():
    print row
"""