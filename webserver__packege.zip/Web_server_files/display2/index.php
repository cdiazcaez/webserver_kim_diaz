<?php
#ALT+SHIFT+F Organiza lineas de codigo

include_once 'app/Connection.inc.php';  //para abrir y cerrar coneccion y manejar con el objeto estatico
include_once 'app/repositoryUser.inc.php';

$tittle = 'Decision Assist System';

include_once 'templates/document-declaration.inc.php';
//include_once 'templates/navbar.inc.php';
//alt+Shift+F formatear codigo, 
?>

<!-- barra de navegacion-->

<!--working with the index usando jumbotron -->
<div class="container">
    <div class="jumbotron">
        <h2>Decision Assist System for Threat Prediction</h2>
        <p>
            Collaborative Data Collection, Rule Generation, and Tracking
        </p>
    </div>
    <!-- nunca poner un container dentro de otro -->
    <div class="container">
        <div class="row"> <!-- dentro de un container siempre va una fila -->
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading"><h3><strong>Decision Rules</strong></h3></div>
                <div class="panel-body">
                    <div class="form-group">
                        <form action='' method="POST" enctype="multipart/form-data"> 
                            <table>
                                <h4>Upload CSV file:</h4>
                                <label id="#bb"> Enter Your File
                                    <input type="file"  id="file" accept=".csv" id="csv" name="csv" required></label><br>
                                <input type="submit" class="submit" value="Submit"><br><br>

                                <!-- ------------------------------------------- -->

                                <?php
                                include_once 'app/config.inc.php';   // including connection credentials

                                if (isset($_FILES['csv']['size']) > 0) {     //comprobar archivo existe, so, size is more than 0
                                    $csv = $_FILES['csv']['tmp_name'];
                                    $filename = $_FILES['csv']['name'];
                                    //$handle = fopen($csv,'r');
                                    $x = 0;
                                    $data = array();
                                    $fichero = fopen($csv, 'r');   // f open en php, para entar al file temporal, y r es privilegio solo lectura
                                    while (($datos = fgetcsv($fichero, 1000)) != FALSE) { // mil registros, si es cero es registro iliminado 
                                        //fgetcsv lee campos de achivo cvs, cuando no sea falso,entra al while para recorrer al file, \
                                        //
                                                           $x++;
                                        if ($x > 1) {// cero comienza a leer desde la fila 1, en caso fila 1 sean headers, x>1
                                            $data[] = '("' . $datos[0] . '","' . $datos[1] . '","' . $datos[2] . '","' . $datos[3] . '","' . $datos[4] . '","' . $datos[5] . '","' . $datos[6] . '","' . $datos[7] . '","' . $datos[8] . '","' . $datos[9] . '","' . $datos[10] . '","' . $datos[11] . '","' . $datos[12] . '","' . $datos[13] . '","' . $datos[14] . '","' . $datos[15] . '","' . $datos[16] . '","' . $datos[17] . '")';

                                            // }   
                                        }
                                    }
                                }
                                global $out;
                                try {
                                    $conn = new PDO("mysql:host=$server_name;dbname=$database_name", $user_name, $password);
                                    // set the PDO error mode to exception
                                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                    if (isset($data)) {
                                        $inserta = "insert into realdata(HT0, HT1, HT2, HT3, HT4, HT5, HT6, HT7, HT8, HT9, HT10, HT11, HT12, HT13, HT14, HT15, HT16, CLASS) values " . implode(",", ($data));
                                    }
                                    if (isset($inserta)) {
                                        $conn->exec($inserta);
                                        echo "<br><h4>New record " . $filename . " was created</h4>";
                                        echo "<h4>Last Database Update: " . date("l jS \of F Y - h:i A") . "</h4>";
                                        //echo  ". date("l jS \of F Y - h:i A") .;
                                        ini_set('max_execution_time', 300);
                                        $command = escapeshellcmd('C:\Python2\python2.exe C:\xampp\htdocs\prac_REALDATA.py');
                                        $rules = shell_exec($command);
                                        echo "<pre>$rules</pre>";
                                        $conn->exec("TRUNCATE TABLE rules");
                                        $conn->exec("insert into rules(rules) Values('$rules')");
                                    }
                                } catch (PDOException $ex) {
                                    print "ERROR:" . $ex->getMessage() . "<br>";
                                    die();
                                }
                                $conn = null
                                ?>
                            </table>
                        </form>
                        <form action='' method="POST" enctype="multipart/form-data">
                            <table>
                                <h4>Display Most Updated Rules:</h4>
                                <button name="ReqRules" class="click">Display</button><br><br>
                                <?php
                                include_once 'app/config.inc.php';
                                try {
                                    $conn = new PDO("mysql:host=$server_name;dbname=$database_name", $user_name, $password);
                                    // set the PDO error mode to exception
                                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                                    if (isset($_POST['ReqRules'])) {
                                        ini_set('max_execution_time', 300);

                                        $stmt = $conn->prepare("SELECT rules FROM rules");
                                        $stmt->execute();

                                        //echo 'hola';
                                        //$result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
                                        // header('Content-Type: application/json');
                                        $res = $stmt->fetchColumn(0);
                                        $results = json_encode($res);
                                        $results = stripcslashes($results);
                                        //$results = addslashes($result);
//echo ty

                                        //echo gettype($results);
                                        if ($results == "false") {
                                            echo "<pre>DataBase is empty</pre>";
                                        } else {
                                            echo "<pre>$results</pre>";
                                        }



                                        //echo "<pre>$results</pre>";
                                        //foreach (new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k => $v) {
                                        //  echo $v;
                                    }
                                } catch (PDOException $ex) {
                                    print "ERROR:" . $ex->getMessage() . "<br>";
                                    die();
                                }
                                $conn = null

                                //$command = escapeshellcmd('C:\Python2\python2.exe C:\xampp\htdocs\prac_REALDATA.py');
                                // $rules = shell_exec($command);
                                //echo "<pre>$rules</pre>";
                                //setcookie("TestCookie", $rules, time() + 3600);
                                // echo $rules;
                                //echo "hola";
                                ?>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="row"> 
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading"><h3><strong>Trend Tracking</strong></h3></div>
                        <div class="panel-body">
                            <div class="form-group">
                                <form action='' method="POST" enctype="multipart/form-data">
                                    <div class="btn-group">
                                        <button  name="click1" class="click">Venezuela</button>
                                        <!-- <button name="click2" class="click">Argentina</button> -->
                                        <button  name="click3" class="click">Bahrain</button>
                                        <button  name="click4" class="click">Suriname</button>
                                        <button  name="click5" class="click">Comoros</button><br><br><br>

                                        <?php
//if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//Venezuela
                                        if (isset($_POST['click1'])) {
                                            ini_set('max_execution_time', 300);
                                            $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\Server_ed_P4Lap2_Venezuela.py');
//$comLegend = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\legend.py');
                                            $out = shell_exec($com);
//echo '<img src="C:\xampp\htdocs\laplace_stat\test.png" alt="">';
//echo '<img src="test.png" width="350" height="350" class="center"><br>';
                                            echo '<img src="test.png" class="center"><br>';
                                            echo "<br>";
                                            echo "<pre class='LSA'>$out</pre>";
                                            $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\legend.py');
                                            $out = shell_exec($com);
                                            echo "<pre class='legend'>$out</pre>";
                                        }
//Argentina
//if (isset($_POST['click2'])) {
//    $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\Server_ed_P4Lap2_Argentina.py');
//  $out = shell_exec($com);
//   echo "<pre>$out</pre>";
// }
//Bahrain
                                        if (isset($_POST['click3'])) {
                                            ini_set('max_execution_time', 300);

                                            $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\Server_ed_P4Lap2_Bahrain.py');
                                            $out = shell_exec($com);
                                            echo '<img src="test.png" class="center"><br>';
                                            echo "<br>";
                                            echo "<pre class='LSA'>$out</pre>";
                                            $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\legend.py');
                                            $out = shell_exec($com);
                                            echo "<pre class='legend'>$out</pre>";
                                        }
//Suriname
                                        if (isset($_POST['click4'])) {
                                            ini_set('max_execution_time', 300);

                                            $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\Server_ed_P4Lap2_Suriname.py');
                                            $out = shell_exec($com);
                                            echo '<img src="test.png" class="center"><br>';
                                            echo "<br>";
                                            echo "<pre class='LSA'>$out</pre>";
                                            $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\legend.py');
                                            $out = shell_exec($com);
                                            echo "<pre class='legend'>$out</pre>";
                                        }
//Comoros
                                        if (isset($_POST['click5'])) {
                                            ini_set('max_execution_time', 300);

                                            $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\Server_ed_P4Lap2_Comoros.py');
                                            $out = shell_exec($com);
                                            echo '<img src="test.png" class="center"><br>';
                                            echo "<br>";
                                            echo "<pre class='LSA'>$out</pre>";
                                            $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\legend.py');
                                            $out = shell_exec($com);
                                            echo "<pre class='legend'>$out</pre>";
                                        }
                                        ?>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include_once 'templates/document-closure.inc.php';
?>
