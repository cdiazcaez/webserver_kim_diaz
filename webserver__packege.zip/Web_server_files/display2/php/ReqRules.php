<?php

if (isset($_POST['ReqRules'])) {
    ini_set('max_execution_time', 300);
    $command = escapeshellcmd('C:\Python27\python2.exe C:\xampp\htdocs\prac_REALDATA.py');
    $output = shell_exec($command);
    echo "<pre>$output</pre>";
}
?>
