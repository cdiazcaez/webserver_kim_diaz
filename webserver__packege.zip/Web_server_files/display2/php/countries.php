<?php

if (isset($_POST['click1'])) {
    $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\Server_ed_P4Lap2.py');
    $out = shell_exec($com);
    echo '<img src="test.png" class="center"><br>';
    echo "<br>";
    echo "<pre class='LSA'>$out</pre>";
    $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\legend.py');
    $out = shell_exec($com);
    echo "<pre class='legend'>$out</pre>";
}
?>

