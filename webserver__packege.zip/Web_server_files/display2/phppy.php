<?php
    $com = escapeshellcmd('C:\Python3\python3.exe C:\xampp\htdocs\laplace_stat\Server_ed_P4Lap2_Venezuela.py');
    $out = shell_exec($com);
    echo "<br>";
    echo "<pre>$out</pre>";

?>
