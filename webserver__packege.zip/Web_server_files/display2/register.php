<!DOCTYPE html> 
<html> 
  <head> 
    <title>Prueba de Bootstrap</title> 
    <link href="css/bootstrap.min.css" rel="stylesheet"> 
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head> 
<body> 
  <div class="container">
    
    <div class="btn-group">
      <button type="button" class="btn btn-default">1</button>
      <button type="button" class="btn btn-default">2</button>
      <button type="button" class="btn btn-default">3</button>
    </div>
    <hr>
    <div class="btn-toolbar" role="toolbar">
      <div class="btn-group">
        <button type="button" class="btn btn-default">uno</button>
        <button type="button" class="btn btn-default">dos</button>
        <button type="button" class="btn btn-default">tres</button>
        <button type="button" class="btn btn-default">cuatro</button>
      </div> 
      <div class="btn-group">
        <button type="button" class="btn btn-default">one</button>
        <button type="button" class="btn btn-default">two</button>
        <button type="button" class="btn btn-default">three</button>
        <button type="button" class="btn btn-default">four</button>
      </div>
     </div>
  </div>
</body> 
</html> 
