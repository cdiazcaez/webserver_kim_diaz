<?php
include_once 'app/config.inc.php';   // including connection credentials

if (isset($_FILES['csv']['size']) > 0) {
    $csv = $_FILES['csv']['tmp_name'];
    $filename = $_FILES['csv']['name'];
    //$handle = fopen($csv,'r');
    $x = 0;
    $data = array();
    $fichero = fopen($csv, 'r');
    while (($datos = fgetcsv($fichero, 1000)) != FALSE) {

        $x++;
        if ($x > 1) {
            $data[] = '("' . $datos[0] . '","' . $datos[1] . '","' . $datos[2] . '","' . $datos[3] . '","'
                    . $datos[4] . '","' . $datos[5] . '","' . $datos[6] . '","' . $datos[7] . '","' . $datos[8]
                    . '","' . $datos[9] . '","' . $datos[10] . '","' . $datos[11] . '","' . $datos[12] . '","' . $datos[13] . '","'
                    . $datos[14] . '","' . $datos[15] . '","' . $datos[16] . '","' . $datos[17] . '")';

            // }   
        }
    }
}
try {
    $conn = new PDO("mysql:host=$server_name;dbname=$database_name", $user_name, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if (isset($data)) {
        $inserta = "insert into realdata(HT0, HT1, HT2, HT3, HT4, HT5, HT6, HT7, HT8,"
                . " HT9, HT10, HT11, HT12, HT13, HT14, HT15, HT16, CLASS) values " . implode(",", ($data));
    }

    if (isset($inserta)) {
        $conn->exec($inserta);
        echo "<br><h2>New record " . $filename . " was created</h2></br>";
        echo "<h3>Last Database Update: " . date("l jS \of F Y - h:i A") . "</h3>";
        $command = escapeshellcmd('C:\Python27\python.exe C:\xampp\htdocs\prac_REALDATA.py');
        $output = shell_exec($command);
        echo "<pre>$output</pre>";
    }
} catch (PDOException $ex) {
    print "ERROR:" . $ex->getMessage() . "<br>";
    die();
}

$conn = null
?>
