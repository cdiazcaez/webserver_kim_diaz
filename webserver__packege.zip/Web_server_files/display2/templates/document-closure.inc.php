
<!-- se acostumbra a cargar los javascrips files al  
final del body, porque se tardan en subir y presentarse en el webpage, 
el usuario no esperaria con la pagina en blanco,ya se habra mostrado todo lo anterior a esto--> 
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>