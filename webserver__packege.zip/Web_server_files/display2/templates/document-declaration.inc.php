<!DOCTYPE html>    <!-- Tipo del archivo -->

<!-- todo en html funciona con etiquetas <> y hay que cerrarlas se cierra con el /-->


<!-- las etiquetas pueden tener atributos -->
<!-- atributo class, nos permite estilizar varios componentes -->
<!-- por ej, letras negras y azules -->
<!-- id es unico por etiqueta -->
<!-- todo esto es con bootstrap -->

<!--el inc del .inc.php indica que el documento esta creado para ser incluido en otros documentos
//los templates se utilizan para re usar codigo, por ej. en index, como comienza y termina el codgio,
// cada nueva pagina que creamos, como register(usuarios registrados) abri que hacer copy paste del head y demas
//creamos templates para no hacer tanto copy paste -->

<html lang="en">  <!-- language page -->
    <head>
        <meta charset="UTF-8"> <!-- que caracteres se van a usar -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- etiqueta para explorer y demas -->
        <meta name="viewport" content="width=devide-width, initial-scale=1"> <!--el ancho de la pagina sea igual al de la pantalla -->
        <?php
        echo "<title>$tittle</title>";  // es el nombre del tab -->  SI USO COMILLAS SIMPLES '' el titulo sera literal $titulo,  quotes sera el valor de la variable
        date_default_timezone_set('America/New_York');
        ?>
        <!-- incluir achivos css, los files de bootstrap que tienen los colores y estilo general de la web,  -->

        <link href ="css/bootstrap.min.css" rel="stylesheet">  
        <link href ="css/styless.css" rel="stylesheet">


        <!-- rel es para esfecificar el archivo es css, porque hay files sin extension-->

    </head>
    <!-- en el body va lo que el usuario va a ver -->
    <body>



