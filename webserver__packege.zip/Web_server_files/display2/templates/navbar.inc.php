<?php
//Connection ::open_connection();
//$total_users = repositoryUser ::get_all_users(Connection::get_connection());
//echo count($users);     // escribe en la pagina un dato.
//Connection :: end_connection();
include_once 'templates/document-declaration.inc.php';
?>
<nav class="navbar navbar-default navbar-static-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <!-- false es para tamaños de la caja del boton, todo esto lo hace bootstrap con javascript -->
                <!-- button y asignarle classes, toggle para cuando la barra no cabe en la pantallo, ej en movil. -->
                <!--el signo de numero es para diferenciar un id de una clase, casi nunca se usa -->
                <!-- casi todo en ese boton es para leer js con bootstrap, no para el html5-->
                <span class="sr-only">This button move the toolbar</span>    
                <!-- para que el boton se forme: icon-bar -->
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Display</a> <!-- a tag is to create a link, to go to others sites -->
            <!-- href indica a que ruta vas cuando hacer click, la ruta de otro html por ej, si lo dejas en blanco, un click seria un refresh -->
            <!-- hreg con el # es para que no haga nada al  pulsar el boton-->
            <!-- completed hour navbar header -->
        </div>
        <!-- working now with the navbar body-->
        <div id="navbar" class="navbar-collapse collapse">
            <!-- ul = unordered list ej, ingred. receta cocina -->
            <ul class = "nav navbar-nav">
                <li><a href="#">Input</a></li>
                <li><a href="#">output</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <!--total de usuarios sera un dato dinamico, cambiara mientras siguen registrandose usuarios -->
                <!-- el codigo php corre como conjunto, primero run el php al principio de este index, y sigue con el que esta aqui abajo-->

                <!--   <li> 
                       <a href="#">
                           Users Registered:
                <?php
                // echo $total_users
                ?>
                       </a>
   
                   </li>
                -->

                <li><a href="#">Login</a></li>
                <li><a href="register.php">Register</a></li>
            </ul>
        </div>  
    </div>
</nav>
