<?php

include_once 'app/config.inc.php';   // including connection credentials

$ruta = 'Upload/';  //folder to save csv files

foreach ($_FILES as $key) {       // forrearch, when you click upload read file
    //rename file using uploading date
    $nombre = $key["name"];
    $ruta_temporal = $key["tmp_name"];

    $fecha = getdate();
    $nombre_v = $fecha["mday"] . "-" . $fecha["mon"] . "-" . $fecha["year"] . "_" . $fecha["hours"] . "-" . $fecha["minutes"] . "-" . $fecha["seconds"] . ".csv";

    $destino = $ruta . $nombre_v;
    $explo = explode(".", $nombre);   //


    if ($explo[1] != "csv") {   //name.csv, explo[1], one represent csv, like index in array, csv is index 1, checking file is csv
        $alert = 1;
    } else {

        if (move_uploaded_file($ruta_temporal, $destino)) {
            $alert = 2;
        }
    }
}

$x = 0;
$data = array();
$fichero = fopen($destino, "r");
while (($datos = fgetcsv($fichero, 1000)) != FALSE) {
    $x++;
    if ($x > 0) {// cero comienza a leer desde la fila 1, en caso fila 1 sean headers, x>1
        $data[] = '(' . $datos[0] . ',"' . $datos[1] . '","' . $datos[2] . '","' . $datos[3] . '","' . $datos[4] . '","' . $datos[5] . '","' . $datos[6] . '",' . $datos[7] . ')';
    }
}

try {

    $conn = new PDO("mysql:host=$server_name;dbname=$database_name", $user_name, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $inserta = "insert into htvariables values " . implode(",", $data);
    //$sql = "INSERT INTO MyGuests (firstname, lastname, email VALUES ('John', 'Doe', 'john@example.com')";
    // use exec() because no results are returned
    $conn->exec($inserta);
    echo "New record created successfully";
} catch (PDOException $ex) {
    print "ERROR:" . $ex->getMessage() . "<br>";
    die();
}
$conn = null
//fclose($fichero);
//$result -> exec($inserta);
//mysql_query($inserta);
//query($inserta)
///  print("<pre>");
//   print($inserta);
//print("</pre");
//$mysql->query($inserta);
// $inserta="insert into importar values ". implode(",", $data);
//$result = $connection->query($inserta); //
//$result =  self::$connection->query($inserta);
//echo "Importación exitosa!";
?>

