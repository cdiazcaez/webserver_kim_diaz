# P4Lap2.py
# T 10/02/2018
# Laplace Test Statistic 
# for Country Specific P4 Dataset

# v2: We need Laplace for the first 2 dominant variables
#    either it is predictin/tracking for True or False

#todo #####################################  input  A?
# Input: (a) mSUM file (which is the output generated for Rule)
# Input: (b) Country Specific P4 File in CSV format
# Output: 
# 
# WinPython3.6
# 
# Charles Kim
#
from prettytable import PrettyTable
import numpy as np
import matplotlib.pyplot as plt  # For Plotting
from beautifultable import BeautifulTable
from io import BytesIO


#from os import sys, path
#sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))


#print("Laplace Test Statistic Calculation for a Country Specific ABCTp4v2016 Sample Data")
#print("Training sample data we use is : ABCTp4v2016cured.csv")
csvname0 = "ABCTp4v2016cured.csv"
#print(" ")
##print("Which test input do you use?")
##print("p4v2016test101.csv    ------- 101")  # Venezuela
##print("p4v2016test115.csv    ------- 115")  # Suriname
##print("p4v2016test160.csv    ------- 160")  # Argentina
##print("p4v2016test581.csv    ------- 581")  # Comoros
##print("p4v2016test692.csv    ------- 692")  # Bahrain		THE BEST EXAMPLE CASE

#tNo = int(input("Type the last 3 digit number of file name (101, 115, 160, 581, or 692)"))

# csvname=input( "Which Country Specific ample data do you want to use: p4v2016test101(or 610 or 692).csv?")

#todo ##################################################################################################################
tNo = 101
csvname = "p4v2016test101.csv"
#todo ##################################################################################################################
#elif tNo == 115:
 #   csvname = "p4v2016test115.csv"
#elif tNo == 160:
  #  csvname = "p4v2016test160.csv"
#elif tNo == 581:
   # csvname = "p4v2016test581.csv"
#elif tNo == 692:
   # csvname = "p4v2016test692.csv"
#else:
 #   #print("Wrong !!!")

##print(csvname0)  # this is the training sample data

##print ("Which division samples do you want to read")
##print ("0:  CL>=0   1:  CL>=1    2:  CL>=2     3:  CL>=3,  -1: CL>=(-1)    -2: CL>=(-2)")
#CLno = int(input("Type a number: (1 is the usual CL, by the way) "))
#todo ##################################################################################################################
#if CLno == 1:
CLnoS = "1"
#todo ##################################################################################################################
#elif CLno == 2:

#    CLnoS = "2"
#elif CLno == 3:
#    CLnoS = "3"
#elif CLno == 0:
#    CLnoS = "0"
#lif CLno == -1:
 #   CLnoS = "-1"
#elif CLno == -2:
 #   CLnoS = "-2"
#else:
 #   CLnoS = "5"


csvIn1 = "mSUM" + CLnoS + csvname0

#print ("this code now reads the rule mSummary table file", csvIn1)


SUM = np.genfromtxt('C:/xampp/htdocs/laplace_stat/mSUM1ABCTp4v2016cured.csv', delimiter=',', dtype='float16')
ncolS = SUM.shape[1]  # number of columns

#print("SUM table = ", SUM)
# Row0: Variable
# Row1: Rule Condition (or "Verdict")
# Row2: <p>
# Row3: <e>
# Row4: Thereshold Value of the Variable

vOrd = np.zeros(10, dtype='int16')
vOrd = np.int16(SUM[0, :])
vDct = np.zeros(10, dtype='int16')
vDct = np.int16(SUM[1, :])
Prob = SUM[2, :]
ME = SUM[3, :]
TH = SUM[4, :]

# TH=np.genfromtxt(csvIn2,delimiter=',',dtype='float16')

#print ("vOrd=", vOrd)
#print ("vDct=", vDct)
#print ("<p>=", Prob)
#print ("<e>=", ME)
#print("TH = ", TH)

#
#            =         ==     =====  =         ==        ====   ======
#           =        =  =    =    = =        =  =      =    =  =
#          =       =    =   =    = =       =     =   =        =
#         =      ========  =====  =      ========  =         ======
#     	 =      =      =  =      =      =      =  =         =
#     	=      =      =  =      =      =      =   =     =  =
#     ======= =      =  ==    ======= =      =    ====   =======

# 1 Read Training Sample Data
#todo ##################################################################################################################
rawDat = np.genfromtxt('C:/xampp/htdocs/laplace_stat/p4v2016test101.csv', delimiter=',', dtype='float32')
#todo ##################################################################################################################
nrow = rawDat.shape[0]  # of rows (axis 0)
#print("nrow=", nrow)

nStep = Prob.size  # Number of variables in the rule table

mcol = TH.size  # in the mSUM file

ncol = rawDat.shape[1]  # of cols (axis 1) i.e.,8

#print("ncol=", ncol)

# 2 From the mSUM rule table, pick the very first 2 variables
#
var1 = -1  # selected variable number for
cond1 = -1  # Condition of the selected variable (1 or 0)
th1 = 0
# which means Verdict must be either 2 (F|1) or 3 (F|0)
var2 = -1  # selected variable number
cond2 = -1  # Condition of the selected variable (1 or 0)
th2 = 0
# for 1st and 2nd variables

var1 = vOrd[0]
var2 = vOrd[1]
cond1 = vDct[0]
cond2 = vDct[1]
th1 = TH[0]
th2 = TH[1]

# 2 Now Initialization for Laplace Statistic
# m[i] --- counting the number of occurrence up to now ( = i)
# Time[i] --- occurrence time (year)
# sum[i] -- sum of all previous occurrence times (year) up to now
# mu[i] --- mean of the occurrence times  = sum[i]/m[i]
# L[i] equation
# s[i] std dev for all occurrence times up to now ( = 0 if m<2)
# La[i] equation ( = if m<2)

# the array size of all above is at max the sample number of the testing data (= nrow)

# Testing with a single column data for L and La calculation check

Time = np.array([1, 5, 7, 14, 15, 16, 17, 18, 19, 20, 22, 23, 24, 25, 26])

nrow = Time.shape[0]

m = np.zeros(nrow, dtype='int16')
t = np.zeros(nrow, dtype='int16')
sum = np.zeros(nrow, dtype='int16')
mu = np.zeros(nrow, dtype='float16')
sum2 = np.zeros(nrow, dtype='int16')
mu2 = np.zeros(nrow, dtype='float16')
s = np.zeros(nrow, dtype='float16')
L = np.zeros(nrow, dtype='float16')
La = np.zeros(nrow, dtype='float16')
# sdv=np.zeros(nrow, dtype='float16')
npstd = np.zeros(nrow, dtype='float16')

# m[i]=1
tempsum = 0
tempsum2 = 0
# mu[i]=0
i = 0
#print("L and La without function call")
#print("# m Time  Sum  mu      s       L        La")
while i < nrow:
    m[i] = i + 1
    tempsum = Time[i]
    if i == 0:
        sum[i] = tempsum
    else:
        sum[i] = tempsum + sum[i - 1]

    mu[i] = sum[i] / m[i]

    # std dev calculation
    # std = np.sqrt(mean(x^2) - mean(x)^2)
    # std = std* sqrt(N/(N-1))

    L[i] = (mu[i] - Time[i] / 2.0) / (Time[i] * np.sqrt(1 / (12 * m[i])))

    # The basic slice syntax is i:j:k where i is the starting index,
    # j is the stopping index, and k is the step (k\neq 0).
    # A[:k] is all the elements up to k-th from start

    # np.std calclate stdev as if the samples are the whole population
    # Excel stdev calculates stdev as if the samples are drawn from a popularion (so sqrt((n-1)/(n))
    # is multiplied
    # Excel, stdevp calculates stdev as np.std does
    # np.std(s, ddof=1) option behaves like stdev of Excel

    if m[i] != 1:
        s[i] = np.std(Time[:i + 1])

    if s[i] != 0:
        La[i] = L[i] * mu[i] / s[i]

    #print(i, m[i], Time[i], "  ", sum[i], "  ", mu[i], " ", s[i], " ", L[i], " ", La[i])

    #	#print("np std = ",npstd[i])

    i += 1


# Above calculation works -- checked with a known case
# Now the main part

# Make it in to a function
# (1) Read the Time array
# Produces La
# -------------------------------------
def laplaceA(Var):
    vrow = Var.shape[0]
    m = np.zeros(vrow, dtype='int16')
    sum = np.zeros(vrow, dtype='int16')
    mu = np.zeros(vrow, dtype='float16')
    L = np.zeros(vrow, dtype='float16')
    La = np.zeros(vrow, dtype='float16')
    npstd = np.zeros(nrow, dtype='float16')

    tempsum = 0

    i = 0
    #print("# m Time  Sum  mu   s        L        La")
    while i < vrow:
        m[i] = i + 1
        tempsum = Var[i]

        if i == 0:
            sum[i] = tempsum

        else:
            sum[i] = tempsum + sum[i - 1]

        mu[i] = sum[i] / m[i]

        L[i] = (mu[i] - Var[i] / 2.0) / (Var[i] * np.sqrt(1 / (12 * m[i])))

        # The basic slice syntax is i:j:k where i is the starting index,
        # j is the stopping index, and k is the step (k\neq 0).
        # A[:k] is all the elements up to k-th from start

        if m[i] != 1:
            npstd[i] = np.std(Var[:i + 1])

        # np.std calclate stdev as if the samples are the whole population
        # Excel stdev calculates stdev as if the samples are drawn from a popularion (so sqrt((n-1)/(n))
        # is multiplied
        # Excel, stdevp calculates stdev as np.std does
        # np.std(s, ddof=1) option behaves like stdev of Excel

        if npstd[i] != 0:
            La[i] = L[i] * mu[i] / npstd[i]

        #print(i, m[i], Var[i], "  ", sum[i], "  ", mu[i], " ", npstd[i], "  ", L[i], "   ", La[i])
        i += 1
    return (La[vrow - 1])


#print("La calculation with function 'laplA' call")

Lapa = laplaceA(Time)
#print(" ")
#print("La = ", Lapa)


# Need to revised the Laplace function
# so that we can choose the entires in the TimeDat or rawDat
def laplace2A(Tm, Var):  # Tm dictates the max number of Time samples
    #	vrow= Var.shape[0]
    vrow = Tm
    m = np.zeros(vrow, dtype='int16')
    sum = np.zeros(vrow, dtype='int16')
    mu = np.zeros(vrow, dtype='float16')
    L = np.zeros(vrow, dtype='float16')
    La = np.zeros(vrow, dtype='float16')
    npstd = np.zeros(nrow, dtype='float16')

    tempsum = 0

    i = 0
    #print("# m Time      Sum   mu         s        L        La")
    while i < Tm:
        m[i] = i + 1
        tempsum = Var[i]

        if i == 0:
            sum[i] = tempsum

        else:
            sum[i] = tempsum + sum[i - 1]

        mu[i] = sum[i] / m[i]

        L[i] = (mu[i] - Var[i] / 2.0) / (Var[i] * np.sqrt(1 / (12 * m[i])))

        if m[i] != 1:
            npstd[i] = np.std(Var[:i + 1])

        if npstd[i] != 0:
            La[i] = L[i] * mu[i] / npstd[i]

        #		#print(i, m[i], Var[i], "  ", sum[i], "  ",mu[i], " ",npstd[i], "  ", L[i], "   ",
        #                La[i])

        i += 1

    #print("Time  L   and La:")
    #print(Var[Tm - 1])
    #print(L[Tm - 1])
    #print(La[Tm - 1])

    #	return (L[Tm-1])	# or La[Tm-1] for LaplaceA
    return (np.stack((Var[Tm - 1], L[Tm - 1], La[Tm - 1])))  # or La[Tm-1] for LaplaceA


#print("La calculation with function 'lapl2A' call")

Lapa2 = laplace2A(Time.shape[0], Time)
#print(" ")
#print("L = ", Lapa2)

# Now back to the Test Data
# We have the following Information
#print("var1  cond1    th1")
#print(var1, "      ", cond1, "    ", th1)
#print("var2  cond2    th2")
#print(var2, "      ", cond2, "    ", th2)

# nrow:  number of total samples in the test file
# #print("rawDat\n", rawDat)
nrow = rawDat.shape[0]  # of rows (axis 0)
Timedat1 = np.zeros(nrow, dtype='int16')
Timedat2 = np.zeros(nrow, dtype='int16')
# tTimeset = np.zeros(nrow, dtype='int16')
sYear = rawDat[0, 0] - 1  # The first entry year of the sample data
Lap1 = np.zeros(8, dtype='float16')  # 7 items produced for Lap and LapA
Lap2 = np.zeros(8, dtype='float16')

# The first Time entry must be the number of years
# from the record starting year (not the real year like 1973)
#
j = 0
k1 = 0
k2 = 0  # counter for occurrence and the number of entries in Timedat
#print("j  var1/2 cond1/2 k1/2 Year   rawDat[j,var1/2]  Timedat[k1/2]")
while j < nrow:
    if cond1 == 0:
        if rawDat[j, var1] > th1:
            Timedat1[k1] = rawDat[j, 0] - sYear
            #print(j, var1, cond1, k1, rawDat[j, 0], rawDat[j, var1], Timedat1[k1])
            k1 += 1
            #			#print("(T|1) ", laplace2A(k1,Timedat1))
            #print("(T|1) ", np.hstack((np.array([var1, cond1, k1, rawDat[j, 0]], dtype='int16'), laplace2A(k1, Timedat1))))
            Lap1 = np.vstack((Lap1, np.hstack(
                (np.array([j, var1, cond1, k1, rawDat[j, 0]], dtype='int16'), laplace2A(k1, Timedat1)))))
    if cond1 == 1:
        if rawDat[j, var1] < th1:
            Timedat1[k1] = rawDat[j, 0] - sYear
            #print(j, var1, cond1, k1, rawDat[j, 0], rawDat[j, var1], Timedat1[k1])
            k1 += 1
            #			#print("(T|0) ", laplace2A(k1,Timedat1))
            #print("(T|0) ", np.hstack((np.array([var1, cond1, k1, rawDat[j, 0]], dtype='int16'), laplace2A(k1, Timedat1))))
            Lap1 = np.vstack((Lap1, np.hstack(
                (np.array([j, var1, cond1, k1, rawDat[j, 0]], dtype='int16'), laplace2A(k1, Timedat1)))))

    if cond1 == 2:
        if rawDat[j, var1] > th1:
            Timedat1[k1] = rawDat[j, 0] - sYear
            #print(j, var1, cond1, k1, rawDat[j, 0], rawDat[j, var1], Timedat1[k1])
            k1 += 1
            #			#print("(F|1) ", laplace2A(k1,Timedat1))
            #print("(F|1) ", np.hstack((np.array([var1, cond1, k1, rawDat[j, 0]], dtype='int16'), laplace2A(k1, Timedat1))))
            Lap1 = np.vstack((Lap1, np.hstack(
                (np.array([j, var1, cond1, k1, rawDat[j, 0]], dtype='int16'), laplace2A(k1, Timedat1)))))

    if cond1 == 3:
        if rawDat[j, var1] < th1:
            Timedat1[k1] = rawDat[j, 0] - sYear
            #print(j, var1, cond1, k1, rawDat[j, 0], rawDat[j, var1], Timedat1[k1])
            k1 += 1
            #			#print("(F|0) ", laplace2A(k1,Timedat1))
            #print("(F|0) ", np.hstack((np.array([var1, cond1, k1, rawDat[j, 0]], dtype='int16'), laplace2A(k1, Timedat1))))
            Lap1 = np.vstack((Lap1, np.hstack(
                (np.array([j, var1, cond1, k1, rawDat[j, 0]], dtype='int16'), laplace2A(k1, Timedat1)))))
    # For cond2
    if cond2 == 0:
        if rawDat[j, var2] > th2:
            Timedat2[k2] = rawDat[j, 0] - sYear
            #print(j, var2, cond2, k2, rawDat[j, 0], rawDat[j, var2], Timedat2[k2])
            k2 += 1
            #			#print("(T|1) ", laplace2A(k2,Timedat2))
            #print("(T|1) ", np.hstack((np.array([var2, cond2, k2, rawDat[j, 0]], dtype='int16'), laplace2A(k2, Timedat2))))
            Lap2 = np.vstack((Lap2, np.hstack(
                (np.array([j, var2, cond2, k2, rawDat[j, 0]], dtype='int16'), laplace2A(k2, Timedat2)))))

    if cond2 == 1:
        if rawDat[j, var2] < th2:
            Timedat2[k2] = rawDat[j, 0] - sYear
            #print(j, var2, cond2, k2, rawDat[j, 0], rawDat[j, var2], Timedat2[k2])
            k2 += 1
            #			#print("(T|0) ", laplace2A(k2,Timedat2))
            #print("(T|0) ", np.hstack((np.array([var2, cond2, k2, rawDat[j, 0]], dtype='int16'), laplace2A(k2, Timedat2))))
            Lap2 = np.vstack((Lap2, np.hstack(
                (np.array([j, var2, cond2, k2, rawDat[j, 0]], dtype='int16'), laplace2A(k2, Timedat2)))))
    if cond2 == 2:
        if rawDat[j, var2] > th2:
            Timedat2[k2] = rawDat[j, 0] - sYear
            #print(j, var2, cond2, k2, rawDat[j, 0], rawDat[j, var2], Timedat2[k2])
            k2 += 1
            #			#print("(F|1) ", laplace2A(k2,Timedat2))
            #print("(F|1) ", np.hstack((np.array([var2, cond2, k2, rawDat[j, 0]], dtype='int16'), laplace2A(k2, Timedat2))))
            Lap2 = np.vstack((Lap2, np.hstack(
                (np.array([j, var2, cond2, k2, rawDat[j, 0]], dtype='int16'), laplace2A(k2, Timedat2)))))
    if cond2 == 3:
        if rawDat[j, var2] < th2:
            Timedat2[k2] = rawDat[j, 0] - sYear
            #print(j, var2, cond2, k2, rawDat[j, 0], rawDat[j, var2], Timedat2[k2])
            k2 += 1
            #			#print("(F|0) ", laplace2A(k2,Timedat2))
            #print("(F|0) ", np.hstack((np.array([var2, cond2, k2, rawDat[j, 0]], dtype='int16'), laplace2A(k2, Timedat2))))
            Lap2 = np.vstack((Lap2, np.hstack(
                (np.array([j, var2, cond2, k2, rawDat[j, 0]], dtype='int16'), laplace2A(k2, Timedat2)))))
    j += 1

# Try np.vstack as
# A = np.vstack((A, B)) repeatedly

#print("Lap1:", Lap1)
#print("Lap2:", Lap2)

x1 = Lap1[:, 4]  # Year in order
y1 = Lap1[:, 6]  # L

if Lap1[1, 2] == 0 or Lap1[1, 2] == 1:
    label1 = "Trend (for True) with 1st variable"
if Lap1[1, 2] == 2 or Lap1[1, 2] == 3:
    label1 = "Trend (for False) with 1st variable"

if Lap2[1, 2] == 0 or Lap2[1, 2] == 1:
    label2 = "Trend (for True) with 2nd variable"
if Lap2[1, 2] == 2 or Lap1[1, 2] == 3:
    label2 = "Trend (for False) with 2nd variable"
label3 = "Transition"

x2 = Lap2[:, 4]  # Year in occurrence
y2 = Lap2[:, 6]  # L

x3 = rawDat[:, 0]  # Year
y3 = rawDat[:, 17]  # Transition

xmax = max(np.max(x1), np.max(x2)) + 10
ymax = max(np.max(y1), np.max(y2)) + 1
xmin = min(np.max(x1), np.max(x2)) - 10
xmin = sYear - 1

if tNo == 101:
    Ltitle = "Laplace Statistic for Ccode 101 Venezuela"
if tNo == 160:
    Ltitle = "Laplace Statistic for Ccode 160 Argentina"
if tNo == 692:
    Ltitle = "Laplace Statistic for Ccode 692 Bahrain"  # Best Example Case
if tNo == 115:
    Ltitle = "Laplace Statistic for Ccode 115 Suriname"
if tNo == 581:
    Ltitle = "Laplace Statistic for Ccode 581 Comoros"

# Can we plot 2 together ?
fig = plt.figure()
ax = fig.add_subplot(111)
ax.scatter(x1, y1, c='b', label=label1)  # default marker is dot(.)
ax.scatter(x2, y2, c='g', marker="x", label=label2)  #
ax.scatter(x3, y3, c='r', marker='*', label=label3)

#ax.plot(x1, y1, c='b', lw=2)
#ax.plot(x2, y2, c='g', lw=2)
#ax.plot(x3, y3, c='r', lw=2)



plt.title(Ltitle)
# plt.legend(loc = 'upper right')
plt.legend(loc='lower left')
plt.xlabel('Occurrence Year')
plt.ylabel('Laplace Statistic (L)')
plt.xlim(xmin, xmax)
plt.ylim(-4, ymax)
plt.savefig('test')
#plt.show()

# Write Lap1 and Lap2 to CSV files

#csvout1 = "Lap1" + csvname
#csvout2 = "Lap2" + csvname

#np.savetxt(csvout1, Lap1, delimiter=',', fmt='%10.5f')
#np.savetxt(csvout2, Lap2, delimiter=',', fmt='%10.5f')

#print(" =====NOTE====")

##print("The following 2 csv file2 are generated for Laplace Statistic Result")
##print(csvout1)
##print(csvout2)

# END


##print(len(x1))#year in order     #Lap1
##print(len(y1)) #L                     #Lap1

##print(x2) #year in occurence         #Lap2
##print(y2) #l                           #Lap2

##print(x3) #year                  #rawData
##print(y3) #transition             #rawData


array = [[x1,y1],[x2,y2],[x3,y3]]

array_of_tables = []
array2 = []
for _ in array:
    a =[]
    b =[]
    table = BeautifulTable()
    temp2 = [a,b]
    for r in _[0]:
        if r % 1 != 0:
            r = float(r)
            a.append(round(r, 2))
        else:
            a.append(int(r))
    for r in _[1]:
        if r % 1 != 0:
            r = float(r)
            b.append(round(r, 2))
        else:
            b.append(int(r))
    array2.append(a)
    array2.append(b)
    temp3=np.transpose(temp2)
    for _ in temp3:
        table.append_row(_)
   # print(table)
    array_of_tables.append(table)
#print("hi")
index = [0,2,3,4,5]
maxLen = max(map(len,array2))

for item in array2:                # for each item in the list
    while len(item) < maxLen:   # while the item length is smaller than 3
        item.extend([" "] * (maxLen - len(item)))#for a, b in izip_longest(l1, l2, fillvalue=''):
table4 = PrettyTable()

table4.title = 'Laplace Statistic'
table4.field_names = ['1st Variable', 'UL1','2nd Variable','UL2','Transition Year','Transition']
for _ in np.transpose(array2):
    table4.add_row(_)
print(table4)





##   print("{:6} {:6}{:6} {:6}{:6} {:6} ".format(array2[0][_],array2[1][_],array2[2][_],array2[3][_],array2[4][_],array2[5],[_]))


#for _ in range(5):        # generate values for columns
    #print(round(d[3][_],2),d[4][_],'\t',d[5][_])
    #print("{:6} {:6}{:6} {:6}{:6} {:6} ".format(dec[0][_],dec[1][_],dec[2][_],dec[3][_],dec[4][_],dec[5],[_]))


