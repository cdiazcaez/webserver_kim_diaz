from prettytable import PrettyTable

table_legend = PrettyTable()
table_legend.title ='Legend'
column_names = ['Confidence Level', 'Z-Score']
table_legend.add_column(column_names[0],['70%','75%','80%','85%','90%','92%','95%','96%','98%','99%'])
table_legend.add_column(column_names[1],[1.04, 1.15, 1.28, 1.44, 1.65, 1.75, 1.96, 2.05, 2.33, 2.58])

print(table_legend)