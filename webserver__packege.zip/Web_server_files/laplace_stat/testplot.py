from beautifultable import BeautifulTable
import numpy as np

Human_Terrain_0 = [9, 8, 6, 20, 13, 2, 1, 15, 27, 2, 1, 1, 2, 1, 2, 30, 2, 3, 3, 2, 2, 3, 4, 4, 2, 30, 30, 30, 2, 1, 8]
Human_Terrain_1 = [21, 22, 24, 10, 17, 28, 29, 15, 3, 28, 29, 29, 28, 29, 28, 0, 28, 27, 27, 28, 28, 27, 26, 26, 28, 0,
                   0, 0, 28, 29, 22]

laplace_table = BeautifulTable()
#laplace_table.append_column(Human_Terrain_0)
a = [Human_Terrain_0,Human_Terrain_1]
for _ in a:
    print (_)
    laplace_table.append_row(_)

print (laplace_table)

b =[]
for _ in a:
    b.append(np.transpose(_))

print (b)

t = BeautifulTable()
tt= np.transpose(b)
for _ in tt:
    t.append_row(_)

print (t)
