#Christian Diaz-Caez

#WinPython2.7
#call my python file from a php

#Script 2



import Real_Data_Step1

if Real_Data_Step1.alert_value == True:
    print Real_Data_Step1.alert

else:
    from Real_Data_Step1 import *

    # Conditional Probability of Threat

    _row_headers = ['fi(1|T)', 'fi(0|NT)', 'fi', 'Ii']
    _cols = [_row_headers]

    table = BeautifulTable()
    # table.append_row(
    # [" ", 'HT variable 0', 'HT variable 1', 'HT variable 2', 'HT variable 3', 'HT variable 4', 'HT variable 5',
    # 'HT variable 6'])z

    Ii_array = []
    for _ in Binary_HT:
        _col = []

        freq_T = 0
        freq_T_nan = 0
        for i in index_T_class:
            if isnan(_[i]) == False:
                if _[i] == 1:
                    freq_T += 1
            elif isnan(_[i]) == True:
                freq_T_nan += 1
        # ##print freq_T
        _col.append('%d/%d' % (freq_T, len(index_T_class)))

        freq_NT = 0
        freq_NT_nan = 0
        ###print  "index_NT_class", index_NT_class
        for i in index_NT_class:
            if isnan(_[i]) == False:
                if _[i] == 0:
                    freq_NT += 1
            elif isnan(_[i]) == True:
                freq_NT_nan += 1

        _col.append('%d/%d' % (freq_NT, len(index_NT_class)))

        deno1 = len(index_T_class) - freq_T_nan
        deno2 = len(index_NT_class) - freq_NT_nan
        ###print "Frequency Threat:", freq_T, "/", deno1
        ###print "Frequency No Threat:", freq_NT, "/", deno2

        # ignoring nan's

        if deno1 == 0 and deno2 == 0:
            fi == 0
        elif deno1 == 0 and deno2 > 0:
            fi = (float32(freq_NT)) / deno2
        elif deno2 == 0 and deno1 > 0:
            fi = (float32(freq_T)) / deno1
        else:
            fi = ((float32(freq_T)) / deno1) + ((float32(freq_NT)) / deno2)

        _col.append('%f' % fi)

        if freq_T_nan + freq_NT_nan == len(index_T_class) + len(index_NT_class):

            Ii = 0
            Ii_array.append(Ii)
        else:
            Ii = abs(fi - 1)
            Ii = round(Ii, 3)
            Ii_array.append(Ii)

        _col.append('%f' % Ii)
        ###print "Ii", Ii

        _cols.append(_col)

    _cols_transpose = [[r[col] for r in _cols] for col in range(len(_cols[0]))]

    _attribute_arr = [''] * len(_cols_transpose[0])
    _attribute_arr = ['Selected Attribute']

    h = max(Ii_array)
    ###print "h = max(Ii)",h
    Ii_array.insert(0, 'Ii')

    # Saving HT index to find the HT with wich we will cacalculate 4 conditional probabilities.
    HT_index = []

    for _ in range(1, len(Ii_array)):
        if h == Ii_array[_]:
            _attribute_arr.append('X')
            HT_index.append(_ - 1)
        else:
            _attribute_arr.append('')

    #
    ###print _attribute_arr
    _cols_transpose.append(_attribute_arr)

    for _ in _cols_transpose:
        table.append_row(_)
    ###print(table)
    # ##print " "
    # ##print HT_index
    for _ in _cols_transpose:
        table.append_row(_)

    # Best attribute is selected from HT variable 4   ### arreglar principio codigo HT variables comeinzan en HT var 1

    # Conditional probability of T and NT given cero

    count1 = 0  # counting zeros  in threat class outcomes [:21]
    count2 = 0  # counting ones  in threat class outcomes [:21]
    for i in index_T_class:
        if isnan(Binary_HT[HT_index[0]][i]) == False:
            if Binary_HT[HT_index[0]][i] == 0:
                count1 += 1
            else:
                count2 += 1
    total1 = 0
    for _ in Binary_HT[HT_index[0]]:
        if isnan(_) == False:
            if _ == 0:
                total1 += 1

    if total1 == 0:
        T_given_cero = 0
    elif total1 > 0:
        T_given_cero = float32(count1) / total1

    total2 = 0
    for _ in Binary_HT[HT_index[0]]:
        if isnan(_) == False:
            if _ == 1:
                total2 += 1

    if total2 == 0:
        T_given_one = 0
    elif total2 > 0:
        T_given_one = float32(count2) / total2

    count3 = 0  # counting zeros  in no-threat class outcomes [:21]
    count4 = 0  # counting ones  in no-threat class outcomes [:21]
    for i in index_NT_class:
        if isnan(Binary_HT[HT_index[0]][i]) == False:
            if Binary_HT[HT_index[0]][i] == 0:
                count3 += 1
            else:
                count4 += 1

    total3 = total1
    total4 = total2

    if total3 == 0:
        NT_given_zero = 0
    elif total3 > 0:
        NT_given_zero = float32(count3) / total3
    if total4 == 0:
        NT_given_one = 0
    elif total4 > 0:
        NT_given_one = float32(count4) / total4
        ###print count4
        ###print total4
        ###print NT_given_one

    # ##print "T_given_cero =", count1, "/", Binary_HT[HT_index[0]].count(0)
    # ##print "T_given_one =", count2, "/", Binary_HT[HT_index[0]].count(1)
    # ##print "NT_given_zero=" , count3, "/", Binary_HT[HT_index[0]].count(0)
    # ##print "NT_given_one = ", count4 ,  "/", Binary_HT[HT_index[0]].count(1)

    #   ##print "NT_given_one:", Binary_HT[HT_index[0]][-10:].count(1), "/", Binary_HT[HT_index[0]].count(1)

    table_cond_prob = BeautifulTable()
    table_cond_prob.append_row(
        ['p %d' % HT_index[0] + '(T|0)', 'p %d' % HT_index[0] + '(NT|0)', 'p %d' % HT_index[0] + '(T|1)',
         'p %d' % HT_index[0] + '(NT|1)'])
    ###print HT_index[0]
    _col_cp = []

    # Binary_HT[HT_index[0]][:21]
    _col_cp.append('%d/%d' % (count1, total1))
    _col_cp.append('%d/%d' % (count3, total3))
    _col_cp.append('%d/%d' % (count2, total2))
    _col_cp.append('%d/%d' % (count4, total4))

    table_cond_prob.append_row(_col_cp)
    # ##print _col_cp
    # Finding highest conditional probability to build the rule pattern

    _max_prob = []
    _con_prob_arr = [T_given_cero, NT_given_zero, T_given_one, NT_given_one]
    _cp_max = max(_con_prob_arr)

    ###print _con_prob_arr
    ###print "MAXIMUM", _cp_max

    # todo abajo, ver si esto lo necesito, camibar el --->T,

    for _ in range(len(_con_prob_arr)):
        if _cp_max == _con_prob_arr[_]:
            # ##print "Step", num_step, ":", _rule[_], "with", "<p> =", "%.2f" % _MEP[_], "<e>=", "%.2f" % _error[_]
            if _ == 0:
                _max_prob.append('R: A' + str(HT_index[0]) + ' = 0 ---> T')

            if _ == 1:
                _max_prob.append('R: A' + str(HT_index[0]) + ' = 0 ---> NT')

            if _ == 2:
                _max_prob.append('R: A' + str(HT_index[0]) + ' = 1 ---> T')

            if _ == 3:
                _max_prob.append('R: A' + str(HT_index[0]) + ' = 1 ---> NT')

        else:
            _max_prob.append('')

    table_cond_prob.append_row(_max_prob)

    ###print table_cond_prob

    ###print " "
    # cadena_2 = "Unbiased Probability".capitalize()
    ###print cadena_2.center(76, "=")
    ###print " "
    arr = []

    ###print "BinaryHT0", Binary_HT[0]
    ###print _con_prob_arr
    ###print _cp_max

    for _ in range(len(Binary_HT[0])):
        # if isnan(Binary_HT[HT_index[0]][_]) == True:
        #  ##print "  puta"

        if isnan(Binary_HT[HT_index[0]][_]) == False:
            if _cp_max == _con_prob_arr[0] or _con_prob_arr[1]:
                if Binary_HT[HT_index[0]][_] == 1:
                    arr.append(_)
            elif __cp_max == _con_prob_arr[2] or _con_prob_arr[3]:
                if Binary_HT[HT_index[0]][_] == 0:
                    arr.append(_)

    # if a == 0 or a == 1:
    #    p = 0

    # elif a == 2 or a == 3:
    #   p = 1

    ####print "arr:", arr

    _new_table = BeautifulTable()
    # _new_table.append_row(
    #   ["Data No.", "HT variable 0", "HT variable 1", "HT variable 2", "HT variable 3", "HT variable 4", "HT variable 5",
    #   "HT variable 6", "Class"])
    _cols = []

    _new_nodata = []
    for _ in arr:
        _new_nodata.append(No_data[_])

    _cols.append(_new_nodata)

    for ht in Binary_HT:
        _new_HT = []
        for _ in arr:
            _new_HT.append(ht[_])
        _cols.append(_new_HT)
        ###print _new_HT
    # ##print "  jj"

    _new_binaryclass = []

    for _ in arr:
        _new_binaryclass.append(binary_class[_])

    _cols.append(_new_binaryclass)
    ###print _cols
    _cols_transpose = [[r[_new_HT] for r in _cols] for _new_HT in range(len(_cols[0]))]

    for _ in _cols_transpose:
        _new_table.append_row(_)
    ###print(_new_table)

    data = []

    data.append(Data_no)

    for _ in Binary_HT:
        data.append(_)

    data = append(data, [binary_class], 0)

    data_transpose = [[data[j][i] for j in range(len(data))] for i in range(len(data[0]))]


    # for _ in data_transpose:
    ###print _
    # for _ in data_transpose:
    #   ##print _

    def arguments_table(data_transpose):
        #print "newwwwwwwwwwwwww"
        # function to replace elements (string '0' and '1' for 0 and 1
        def str_to_num(array):

            for q, p in enumerate(array):
                if p == '0':
                    array[q] = 0

            for q, p in enumerate(array):
                if p == '1':
                    array[q] = 1
            for q, p in enumerate(array):
                if p == 'nan' or p == 'NAN' or p == 'NaN':
                    array[q] = float('nan')
                    # ##print "hola"
            return

        num_col = len(data_transpose[0])

        ###print "num col", num_col
        ###print len(data_transpose)

        # index_1 = len(data_transpose[0]) - (len(data_transpose[0]) - 1)  # from table(index 1st HT
        # index 0 is No_data, index 1 is 1st HT
        index_2 = len(data_transpose[0]) - 2  # until index last HT
        # we have 9 column, last column is index 8(class column)
        ###print index_2
        index_T_class = []
        index_NT_class = []

        for i in range(len(data_transpose)):  # separate concern
            # ##print "hi"
            x = float(data_transpose[i][index_2 + 1])
            if x == 1:  # equat to threat
                index_T_class.append(i)
            else:
                index_NT_class.append(i)
        ###print index_T_class
        ###print index_NT_class
        ###print len(index_T_class) + len(index_NT_class)

        ###print "indexT",index_T_class
        ###print  "indexNT",index_NT_class
        freq_T_ht = []  # frequency threat    #viene siendo el 21 del 1/21
        freq_T_nan = []
        freq_NT_ht = []
        freq_NT_nan = []
        # working with Threat class
        ###############

        Ii_array = []
        for _ in range(1, num_col - 1):
            _col = []
            count_freq_T_ht = 0
            count_freq_T_nan = 0

            count_freq_NT_ht = 0
            count_freq_NT_nan = 0

            for i in index_T_class:
                x = float(data_transpose[i][_])
                if isnan(x) == False:
                    if x == 1:
                        count_freq_T_ht += 1
                elif isnan(x) == True:
                    count_freq_T_nan += 1
            freq_T_ht.append(count_freq_T_ht)
            freq_T_nan.append(count_freq_T_nan)

            for i in index_NT_class:
                x = float(data_transpose[i][_])
                if isnan(x) == False:
                    if x == 0:
                        count_freq_NT_ht += 1
                elif isnan(x) == True:
                    count_freq_NT_nan += 1
            freq_NT_ht.append(count_freq_NT_ht)
            freq_NT_nan.append(count_freq_NT_nan)
            # ##print "freq_T_nan ", freq_T_nan
            ###print "freq_NT_nan ", freq_NT_nan

            #####################################################
            # ##print freq_T_ht
            ###print freq_T_nan
            ###print freq_NT_ht
            ###print freq_NT_nan

            ##################################################
            # _col.append('%d/%d' % (freq_T, len(index_T_class)))

            fi_T = []  # conditional (1|T)
            fi_NT = []  # conditional (0|NT)
            fi = []  # sum of fi_T and fi_NT
            I = []  # index attribute
            select_att = []
            # deno1 = len(index_T_class) - freq_T_nan
            #            deno2 = len(index_NT_class) - freq_NT_nan
            ###print "len(index_T_class)", len(index_T_class)
            ###print "len freq_NT_nan", (freq_NT_nan)
            ###print "index_NT_class)", (index_NT_class)
            ###print "freq_T_ht", freq_T_ht
            # freq_T_ht = ht_values_tclass.count(1)  # viene siendo el 1 del 1/21

            for _ in range(len(freq_T_ht)):
                deno1 = len(index_T_class) - freq_T_nan[_]
                # ##print freq_T_nan[_]
                if deno1 > 0:  # todo###############################
                    global fi_value
                    fi_value = float32(freq_T_ht[_]) / deno1
                    fi_value = round(fi_value, 4)
                    fi_T.append(fi_value)
                elif deno1 == 0:
                    fi_value = 0
                    fi_T.append(fi_value)
            # fi_T.append(fi_value)
            # i = 0
            # freq_NT_ht = ht_values_ntclass.count(0)
            for _ in range(len(freq_NT_ht)):
                #  ##print "i = ", i
                # i+=1
                ###print len(index_NT_class)
                # w##print freq_NT_nan[_]

                deno2 = len(index_NT_class) - freq_NT_nan[_]
                if deno2 > 0:
                    fi_value_NT = float32(freq_NT_ht[_]) / deno2
                    fi_value_NT = round(fi_value_NT, 4)
                    fi_NT.append(fi_value_NT)
                elif deno2 == 0:
                    fi_value_NT = 0
                    fi_NT.append(fi_value_NT)

            # ##print freq_NT_ht, "/", freq_NT_class
            # fi_value_NT = round(fi_value_NT, 4)
            # fi_NT.append(fi_value_NT)
        ###print "fi_T",fi_T
        ###print "fi_NT",fi_NT
        for _ in range(len(fi_T)):
            sum = fi_T[_] + fi_NT[_]
            sum = round(sum, 2)
            fi.append(sum)
        # ##print "fi kkk", fi
        #print fi_T
        #print fi_NT
        #print "sum fi", fi
        for _ in range(len(fi)):
            # ##print "pura " ,len(freq_T_ht), len(freq_T_nan), len(freq_NT_ht), len(freq_T_nan)
            ###print  count_freq_T_nan, count_freq_NT_nan , len(index_T_class), len(index_NT_class)
            if freq_T_nan[_] + freq_NT_nan[_] == len(index_T_class) + len(index_NT_class):
                I.append(0)
            else:
                sum = abs(fi[_] - 1)
                sum = round(sum, 2)
                I.append(sum)
        #print "I", I
        # ##print "lenI", len(I)
        attribute = max(I)
        # #print "attribute", attribute

        for _ in range(len(I)):
            if I[_] == attribute:
                # location_att = location_att + _ + 1
                select_att.append("X")
            else:
                select_att.append(" ")
        # #print select_att
        global location_att
        location_att = 0
        ###print "I",I

        for _ in range(len(select_att)):
            if select_att[_] == "X":
                location_att = _ + 1  # si hay mas de un attributo se estara selectionando el ultimo, podria guardar los index
                break   #arreglar, que pasa si la primera columna es toda nan



                # de los highest att y select racndom random.chice(array)
        # #print location_att
        HT_max_att = []  # is the HT with the max att to use in the 4 conditional probabilites calculation
        for _ in range(len(data_transpose)):
            b = data_transpose[_][location_att]
            HT_max_att.append(b)
            str_to_num(HT_max_att)

        # #print HT_max_att
        ###print "HTMAXATT", HT_max_att
        ######################
        # conditional prob. T fiven 0

        conditional_array = []
        conditional_array_num = []
        conditional_array_den = []
        ###############################
        # four conditional probabilities
        # p(T|0) p(NT|0) p(T|1)p(NT|1)

        # p(T | 0) and  p(NT | 0) calculated from THREAT Region

        zeros_T = 0  # cuantos ceros tengo en threat region
        ones_T = 0  # unos en threat region
        nan_T = 0  # nan en threat region    #no lo uso
        for _ in index_T_class:
            x = float(HT_max_att[_])
            if isnan(x) == False:
                if x == 0:
                    zeros_T += 1
                if x == 1:
                    ones_T += 1
            if isnan(x) == True:
                nan_T += 1
        # #print "zeros_T", zeros_T
        # #print "ones_T",ones_T

        zeros_NT = 0  # cuantos ceros tengo en No-threat region
        ones_NT = 0  # ceros en N0-threat
        nan_NT = 0  # nan Non-Threat    #no lo uso
        for _ in index_NT_class:
            x = float(HT_max_att[_])
            if isnan(x) == False:
                if x == 0:
                    zeros_NT += 1
                if x == 1:
                    ones_NT += 1
            if isnan(x) == True:
                nan_NT += 1
        deno_x = zeros_T + zeros_NT
        deno_y = ones_T + ones_NT

        if deno_x > 0:
            T_given_cero = float32(zeros_T) / deno_x
            T_given_cero = round(T_given_cero, 2)

            #print "zeros_T", zeros_T
            #print  "denox", deno_x
            conditional_array_num.append(zeros_T)
            conditional_array_den.append(deno_x)


            NT_given_zero = float32(zeros_NT) / deno_x
            NT_given_zero = round(NT_given_zero, 2)
            #print "zeros NT", zeros_NT
            #print deno_x
            conditional_array_num.append(zeros_NT)
            conditional_array_den.append(deno_x)

            conditional_array.append(T_given_cero)
            conditional_array.append(NT_given_zero)

        elif deno_x == 0:
            conditional_array.append(0)
            conditional_array.append(0)
            conditional_array_num.append(0)
            conditional_array_den.append(0)
            conditional_array_num.append(0)
            conditional_array_den.append(0)
        # #print "hh" ,T_given_cero
        # #print "kk", NT_given_zero
        # p(T | 1) and p(NT | 1) calculated from No - Threat region

        if deno_y > 0:
            T_given_one = float32(ones_T) / deno_y
            T_given_one = round(T_given_one, 2)

            conditional_array_num.append(ones_T)
            conditional_array_den.append(deno_y)

            NT_given_one = float32(ones_NT) / deno_y
            NT_given_one = round(NT_given_one, 2)

            conditional_array_num.append(ones_NT)
            conditional_array_den.append(deno_y)

            conditional_array.append(T_given_one)
            conditional_array.append(NT_given_one)

        elif deno_y == 0:
            conditional_array.append(0)
            conditional_array.append(0)
            conditional_array_num.append(0)
            conditional_array_den.append(0)
            conditional_array_num.append(0)
            conditional_array_den.append(0)
        #print "num", conditional_array_num
        #print "den", conditional_array_den

        rule = max(conditional_array)
        # ##print conditional_array
        # ##print rule
        select_rule = []

        global a  # saving the index with highest conditional prob.0-3
        a = 0
        global u
        global bin_con
        u = 0  # saving the rule as a global to ##print at the final with all the steps rules
        bin_con = 0  # saving the binary condition (0 or 1) to test later the rules.
        # #print  conditional_array
        for _ in range(len(conditional_array)):
            if conditional_array[_] == rule and _ == 0:
                u = 'R: A' + str(location_att - 1) + ' = 0 ---> T '
                select_rule.append(u)
                a = _
                bin_con = 0
            elif conditional_array[_] == rule and _ == 1:
                u = 'R: A' + str(location_att - 1) + ' = 0 ---> NT'
                select_rule.append(u)
                a = _
                bin_con = 0
            elif conditional_array[_] == rule and _ == 2:
                u = 'R: A' + str(location_att - 1) + ' = 1 ---> T '
                select_rule.append(u)
                a = _
                bin_con = 1
            elif conditional_array[_] == rule and _ == 3:
                u = 'R: A' + str(location_att - 1) + ' = 1 ---> NT'
                select_rule.append(u)
                a = _
                bin_con = 1
            else:
                select_rule.append(" ")

        global p
        p = 0
        if a == 0 or a == 1:
            p = '0.0'

        elif a == 2 or a == 3:
            p = '1.0'

        # attribute table
        # ##print " "
        cadena_2 = "Calculation of Attribute".capitalize()
        # ##print cadena_2.center(76, "=")
        # ##print " "

        table_attribute = BeautifulTable()
        # table_attribute.append_row(
        #    [" ", 'HT variable 0', 'HT variable 1', 'HT variable 2', 'HT variable 3', 'HT variable 4', 'HT variable 5',
        #    'HT variable 6'])

        fi_T.insert(0, 'fi(1|T)')
        table_attribute.append_row(fi_T)
        fi_NT.insert(0, 'fi(0|NT)')
        table_attribute.append_row(fi_NT)
        fi.insert(0, 'fi')
        table_attribute.append_row(fi)
        I.insert(0, 'Ii')
        table_attribute.append_row(I)
        select_att.insert(0, 'selected att')
        table_attribute.append_row(select_att)

        # ##print table_attribute
        # ##print " "

        # ##print " "
        cadena_2 = "Unbiased Probability".capitalize()
        # ##print cadena_2.center(76, "=")
        # ##print " "
        # Conditional Probabilities Table
        table_cond_prob = BeautifulTable()
        table_cond_prob.append_row(['p' + str(location_att - 1) + '(T|0)', 'p' + str(location_att - 1) + '(NT|0)',
                                    'p' + str(location_att - 1) + '(T|1)', 'p' + str(location_att - 1) + '(NT|1)'])
        table_cond_prob.append_row(conditional_array)
        table_cond_prob.append_row(select_rule)

        # ##print table_cond_prob
        # ##print " "
        # cadena_2 = "Margin of Error".capitalize()
        # ##print cadena_2.center(76, "=")
        # ##print " "
        #print "conditional array", conditional_array
        #print "rule", rule
        for _ in range(len(conditional_array)):
            if conditional_array[_] == rule:
                global MEP
                # p=(x+1)/(n+2) ----->formula
                MEP = float32(conditional_array_num[_] + 1) / (conditional_array_den[_] + 2)
                #print "den", conditional_array_num[_] + 1, ',', (conditional_array_den[_] + 2)
                MEP = round(MEP, 2)
                #print "MEP", MEP
                # ##print "Maximum Entropy Probability  <p>:", "%.2f" % MEP

                radicant =  (MEP * float32((1 - MEP))) / (conditional_array_den[_] + 2)
                #print "radicant", radicant
                global ek
                ek = math.sqrt(radicant) * 1.96  # 1.96 is z-score value
                ek = round(ek, 2)
                # ##print "Margin of error ek:", "%.2f" % ek

                break
        return (p, location_att)


    _location_att = []
    _binary_condition = []
    _rule = []
    _MEP = []
    _error = []


    def falu(data_temp):


        if len(data_temp) <> 0:
            # ##print " "
            title = "Rule Extraction"
            title = title.upper()
            # ##print  title.center(76, "*")
            arguments_table(data_temp)
            #print "attri", location_att
            _rule.append(u)
            _MEP.append(MEP)
            _error.append(ek)
            _location_att.append(location_att - 1)
            _binary_condition.append(bin_con)
            table = BeautifulTable()
            i = 0  # rows Number
            count = 0
            j = len(data_temp)  # todo  ESTE NO ES EL NUMERO DDE COLUMNAS, XQ FUNDIONA? NUM COLUMN = len(data_temp[0]) = 9 Columns Number
            data_temp_2 = []  # New Table
           # #print data_temp[location_att]
            #print "p", p,  "att,", location_att
            while i < j:
                if data_temp[i][location_att] <>  p:
                    data_temp_2.append(data_temp[i])
                i = i + 1
               # #print len(data_temp)
                ##print len(data_temp_2)
                if i == j:
                    #print "len data temp 2", len(data_temp_2)
                    if len(data_temp_2) == 0:
                        #   ##print "ok2"
                        return
                    else:
                        for _ in range(len(data_temp_2)):
                            ###print data_temp_2[0][1:len(data_temp_2[0]) - 1]
                            ###print data_temp_2[_][1:len(data_temp_2[0]) - 1]
                            if data_temp_2[0][1:len(data_temp_2[0]) - 1] == data_temp_2[_][1:len(data_temp_2[0]) - 1]:
                                count += 1
            for _ in data_temp_2:
                table.append_row(_)
            ###print table

            # ##print data_temp_2

            if len(data_temp_2) <> count:
                # if data_temp == data_temp_2:
                #   return
                if j <> 0:
                    # ##print "count", count
                    # ##print len(data_temp_2)
                    # else:
                    falu(data_temp_2)

        else:
            return


    # Separation of Concern
    falu(data_transpose)  # calling falu function

    # #print " "
    v = "*"
    # #print  v.center(76, "*")

    title = " Desicion-assist rule "
    title = title.upper()
    # #print  title.center(76, "*")

    v = "*"
    # #print  v.center(76, "*")
    # #print(" ")

    for _ in range(len(_rule)):
        num_step = _ + 1
        print "Step", num_step, ":", _rule[_], "with", "p =", "%.2f" % _MEP[_], "e=", "%.2f" % _error[_]

    #print ""

# #print" solo una regla"
# #print" rule is in HT 16 ALL NAN"
"??????????"
